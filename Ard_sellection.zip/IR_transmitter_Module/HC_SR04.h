

//  Microcontroller pin configuration
#ifndef pin_ECHO   
  #define pin_ECHO   (9)       // Defines the number of the digital pin that is attached to the sensor's ECHO pin.
#endif
#ifndef pin_TRIG   
  #define pin_TRIG   (8)       // Defines the number of the digital pin that is attached to the sensor's ECHO pin.
#endif


/*
     Ultrasound Sensor Modules with TRIG and ECHO pins.

   Obs.: The file "C:\Program Files\Arduino\hardware\arduino\avr\cores\arduino\wiring_pulse.c” has the
         implementation of the function 'unsigned long pulseIn(uiint8_t pin, uint8_t state, unsigned
         long timeout)' used to measure the time interval while a digital input was at a specified level. 
         In this file, the function 'micros()' seems to return the clock time of the microcontroller (in 
         an integer number of microseconds since it started to run) and is used to measure time interval
         inside a function.
*/

//  For Ultrasound Sensor Module HC-SR04:
//    Maximum distance:  4.00 meters
//    Minimum distance:  0.02 meters
//    Pulse durationon TRIG pin to start measurement: 10 micro seconds
//    Interval between 2 consecutive measurements:    60 mili seconds

#define DistSensor_D_min     (0.02f)   // Minimum distance that the ultrasound sensor may detect.
#define DistSensor_D_max     (4.00f)   // Maximum distance that the ultrasound sensor may detect.
#define DistSensor_T_trig    (10)      // Time interval, in microseconds, that TRIG pin must be in High level to start a distance measurement.
#define DistSensor_T_wait    (60000L)  // Minimum time between two consecutives distance measurement.
#define DistSensor_AvgN      (6)       // Number of times that the distance will be measured before to calcuçate an average (more precise) value. Maximum value is "255".

// Sound speed in the air (near zero altitude).
#define Vsound_20C           (343.21f)      // Speed of sound in the air (at 20°C and near zero altitude).
const float V_sound = Vsound_20C;           // Initial value for Speed of sound in the air (at 20°C).

// The presence of floating constant in preprocessor expression causes error.
// Beacause of it, the expession " (2 * DistSensor_D_max / Vsound_20C ) * 1000000L < 32767 " must be evaluated manualy.
// If the expression value is "true", the following macro "SmallDataSizeForTime" must be set to "(1)", otherwise, must be set to "(0)".
#define SmallDataSizeForTime (1)
#if (SmallDataSizeForTime == 1)
  typedef uint16_t int_timeU;
#else 
  typedef uint32_t int_timeU;
#endif
int_timeU DistSensor_T_timeout = (2 * DistSensor_D_max / Vsound_20C ) * 1000000L;  // Time (in micro seconds) that sensor's ECHO pin will be at High level if an object is placed the maximum distance that the semsor can measure.



//--- Function Prototyping
float GetDistance(unsigned long *echo_interval = 0x0);
void delayMicrosecondsLong (unsigned long us);
float GetAVGDistance(int measures = 4);



float GetDistance(unsigned long *echo_interval) {
// Estimation reveals that time required to run this function is approximately:
//      T = 5.8273E-3 * D + 2367.188E-6 
//    Where:  
//            T => is the run time, in seconds; 
//            D => is the Distance Measured Between Sensor And Reflective Obstacle, in meters.
//
//    Observation: the parameter with value (5.8273E-3) is given by the time required to the sound 
//                 (frequency=40kHz) run through 1.0 meter at temperature=20.0C and pressure=1.0atm .
//                 But depending on temperature (pressure and frequency vs.speed of sound in dispersive medium)
//                 may change this value. But it can be found with some accuracy using Linear Regression. 
//           
  
    unsigned long echo_wait;   // Time, in micro seconds, in which ECHO pin was at High State.
    float distance;
 
   //  Generate a pulse in TRIG pin.
    int DistSensor_T_trigSartStop  = DistSensor_T_trig / 2 + 1;
    digitalWrite(pin_TRIG, LOW);
    delayMicroseconds(DistSensor_T_trigSartStop );
    digitalWrite(pin_TRIG, HIGH);
    delayMicroseconds(DistSensor_T_trig);
    digitalWrite(pin_TRIG, LOW);
    delayMicroseconds(DistSensor_T_trigSartStop );

    //  Get interval while ECHO pin was in High level.
    echo_wait = pulseIn(pin_ECHO, HIGH, DistSensor_T_timeout);   // This value is given in micro seconds.
    if (echo_interval != 0x0) *echo_interval = echo_wait;
    
    // Calculate the distance.
    distance = (V_sound / 2000000L) * echo_wait ;
    
    return distance;
}


void delayMicrosecondsLong (unsigned long us) {
  
    unsigned long auxL = us / 1000;
    unsigned int  auxI = us - auxL * 1000;   // Calculates the remainder of integer division " auxL = us / 1000 ". 
    delay(auxL);     // Function "void delay(unsigned long ms)" accepts unsigned long (uint32_t) variables. This function is defined in file "wiring.c" .
    delayMicroseconds( auxI );    // Function "void delayMicroseconds(unsigned int us)" does NOT accept unsigned long (uint32_t) variables only unsigned int (uint16_t). This function is defined in file "wiring.c" .
  
}


float GetAVGDistance(int measures) {
    unsigned long echo_interval;   // Auxiliar variable to create a delay between two consecutive measurements. It is Time, in micro seconds, in which ECHO pin was at High State.
    float distance_Avg = 0;
    float distminval = DistSensor_D_max;  // This initial value must allow any first measurement be saved as distminval. 
    float distmaxval = DistSensor_D_min;  // This initial value must allow any first measurement be saved as distmaxval. 

    // Realize distance measurements.
    uint8_t n;
    float aux;
    for (n = 0; n < measures; ++n) {
        aux = GetDistance( &echo_interval );   
                                // Serial.print(n); Serial.print(" : "); Serial.print(aux *100); Serial.print("cm >> ");   // Used for test purposes.
        delayMicrosecondsLong( max(DistSensor_T_wait - DistSensor_T_trig - 2 * (DistSensor_T_trig / 2 + 1) - echo_interval, 0) );
        if (aux < distminval ) {distminval = max(aux, DistSensor_D_min);} // Get the minimum value measured for the distance in all iterations. This will never be less than the minimum distance that the sensor is able to measure.
        if (aux > distmaxval ) {distmaxval = min(aux, DistSensor_D_max);} // Get the maximum value measured for the distance in all iterations. This will never be greater than the maximum distance that the sensor is able to measure.
        distance_Avg += aux;    // Accumulate the values of all measurements.
    }
                            // Serial.println();   // Used for test purposes.

    // Calculate the average measurement
    distance_Avg = (distance_Avg - distminval - distmaxval) / (measures - 2); // The minimum and maximum measurements are excluded from calculation.

    return distance_Avg ;
}
