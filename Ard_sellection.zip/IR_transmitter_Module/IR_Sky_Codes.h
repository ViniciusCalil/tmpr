// SKY codes for IR remote control.
//    NOTE: those codes were obtained by arduino "IRremote.cpp" library.
Controle Remoto SKY
	using: Hash codification in arduino "IRremote.cpp" library.
#define IRCode_power_main   (0xA80E7E5E)
#define IRCode_power_on     (0x6D8867D7)
#define IRCode_power_off    (0x692D04A0)
#define IRCode_volume_up    (0x2FAAD12C)
#define IRCode_volume_down  (0x2FAAD12C)
#define IRCode_channel_up   (0x165412B7)
#define IRCode_channel_down (0x5815B090)
//The button "CONFIRMA" sends continuously the code "IRCode_CONFIRM_0" while the button is pressed, but, after released it sends one (and only one) code "IRCode_CONFIRM_1" .
#define IRCode_CONFIRM_0    (0x75A956A7)
#define IRCode_CONFIRM_1    (0x899B7CDA)
#define IRCode_arrow_up     (0xF24119FE)
#define IRCode_arrow_down   (0xB489062B)
#define IRCode_arrow_right  (0xBC9DF06)
#define IRCode_arrow_left   (0xC53794B4)
#define IRCode_GUIA         (0x427EBE9F)
#define IRCode_SAIR         (0x34498102)
#define IRCode_RETURN_MENU  (0xBB9BDEE7)
#define IRCode_MENU         (0x76CF1379)
#define IRCode_RETURN_CHNNL (0x5BFBFDE9)
#define IRCode_1            (0xC9767F76)
#define IRCode_2            (0xC8155AB1)
#define IRCode_3            (0xB6996DAE)
#define IRCode_4            (0x969AE844)
#define IRCode_5            (0x4AAFAC67)
#define IRCode_6            (0x9C2A936C)
#define IRCode_7            (0x833ED333)
#define IRCode_8            (0x55F2B93)
#define IRCode_9            (0xDE78B0D0)
#define IRCode_0            (0xF32F72D7)
#define IRCode_DASH         (0xBDE97C12)
#define IRCode_GREEN        (0x8C0B38A3)
#define IRCode_YELLOW       (0x2591C110)
#define IRCode_INFO         (0xF640360)
#define IRCode_ENTER        (0x3F23F43)



