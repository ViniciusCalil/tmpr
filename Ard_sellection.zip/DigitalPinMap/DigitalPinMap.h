#ifndef DIGITALPINMAP_H
  #define DIGITALPINMAP_H

typedef struct Ard_pin_dio_add_map {
  // Address map of Digital I/O pins of Arduino.
  volatile uint8_t *ddr;   // Address of the register DDR  of an Arduino PCB pin.
  volatile uint8_t *pin;   // Address of the register PIN  of an Arduino PCB pin.
  volatile uint8_t *port;  // Address of the register PORT of an Arduino PCB pin.
  uint8_t bit;             // Index of the bit position (lsb = 0) of an Arduino PCB pin inside the data of its Digital I/O registers (DDR, PIN, PORT).
  uint8_t bitmask;         // Bitmask of an Arduino PCB pin inside the data of its Digital I/O registers (DDR, PIN, PORT).
  uint8_t timer;           // Index of the Timer of an Arduino PCB pin. That index refers to: TIMER0A,TIMER0B, TIMER1A, TIMER1B,TIMER1C, TIMER2, TIMER2A, TIMER2B.
  uint8_t ardpin;          // Number of the Arduino PCB pin associated with other struct fields.
} ArdPinAddMap;

int8_t ArdDIOPinToAddMap(uint8_t ArdPin, struct Ard_pin_dio_add_map *ArdPAM);
void ShowArdPinDIOAddMap (struct Ard_pin_dio_add_map * ArdPAM);

void ShowArdPinDIOAddMap (struct Ard_pin_dio_add_map * ArdPAM) {
  Serial.print("ArdPin : "); Serial.print(ArdPAM->ardpin);
  Serial.print(" . BitIndex : "); Serial.print(ArdPAM->bit);
  Serial.print(" . BitMask : "); Serial.print(ArdPAM->bitmask);
  Serial.print(" . Timer : "); Serial.print(ArdPAM->timer);
  Serial.print(" . DDR : "); Serial.print((uint16_t)ArdPAM->ddr);
  Serial.print(" ("); Serial.print(*(ArdPAM->ddr));
  Serial.print("). PORT : "); Serial.print((uint16_t)ArdPAM->port);
  Serial.print(" ("); Serial.print(*(ArdPAM->port));
  Serial.print("). PIN : "); Serial.print((uint16_t)ArdPAM->pin);
  Serial.print(" ("); Serial.print(*(ArdPAM->pin));
  Serial.println(").");
}

int8_t ArdDIOPinToAddMap(uint8_t ArdPin, struct Ard_pin_dio_add_map *ArdPAM) {

        // From "wiring_digital.c" function "void pinMode(uint8_t pin, uint8_t mode)".
    //  uint8_t timer = digitalPinToTimer(pin);
    //  uint8_t bit = digitalPinToBitMask(pin);
    //  uint8_t port = digitalPinToPort(pin);
    //  volatile uint8_t *reg, *out;
    //  if (port == NOT_A_PIN) return;
    //  reg = portModeRegister(port);
    //  out = portOutputRegister(port);
    //  if (timer != NOT_ON_TIMER) turnOffPWM(timer);

      // From "Arduino.h" and from "pins_arduino.h"
    // #define digitalPinToPort(P) ( pgm_read_byte( digital_pin_to_port_PGM + (P) ) )
    // #define digitalPinToBitMask(P) ( pgm_read_byte( digital_pin_to_bit_mask_PGM + (P) ) )
    // #define digitalPinToTimer(P) ( pgm_read_byte( digital_pin_to_timer_PGM + (P) ) )
    // #define analogInputToDigitalPin(p)  ((p < 6) ? (p) + 14 : -1)
    // #define analogInPinToBit(P) (P)
    // #define portOutputRegister(P) ( (volatile uint8_t *)( pgm_read_word( port_to_output_PGM + (P))) )
    // #define portInputRegister(P) ( (volatile uint8_t *)( pgm_read_word( port_to_input_PGM + (P))) )
    // #define portModeRegister(P) ( (volatile uint8_t *)( pgm_read_word( port_to_mode_PGM + (P))) )

        // From "Arduino.h"   :  Note that "PROGMEM" is a qualifier that let you access FLASH program memory area.
    // extern const uint16_t PROGMEM port_to_mode_PGM[];
    // extern const uint16_t PROGMEM port_to_input_PGM[];
    // extern const uint16_t PROGMEM port_to_output_PGM[];
    // extern const uint8_t PROGMEM digital_pin_to_port_PGM[];
    // extern const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[];
    // extern const uint8_t PROGMEM digital_pin_to_timer_PGM[];

  uint8_t bitpos;
  uint8_t ArdPortIx;
  uint8_t ArdPortPinMask;
  ArdPAM->ardpin = ArdPin;

  ArdPortPinMask = digitalPinToBitMask(ArdPin);  // Bit mask of 'ArdPin' in AVR microcontroller port registers.
  ArdPAM->bitmask = ArdPortPinMask;
  ArdPAM->timer = digitalPinToTimer(ArdPin);    // Address of  timer register corresponding to  'ArdPin' .
  ArdPortIx = digitalPinToPort(ArdPin);     // Index of AVR microcontroller port (corresponding to 'ArdPin') used in array of struct like: 'port_to_mode_PGM[]', 'port_to_output_PGM[]', 'port_to_input_PGM[]' and 'digital_pin_to_timer_PGM[]'.
  if (ArdPortIx == NOT_A_PIN) return -1;

  ArdPAM->ddr  = portModeRegister(ArdPortIx);    // Address of DDR register  corresponding to  'ArdPin' .
  ArdPAM->port = portOutputRegister(ArdPortIx);  // Address of PORT register corresponding to  'ArdPin' .
  ArdPAM->pin  = portInputRegister(ArdPortIx);   // Address of PIN register  corresponding to  'ArdPin' .
  if ( (ArdPAM->ddr==NOT_A_PORT) || (ArdPAM->port==NOT_A_PORT) || (ArdPAM->pin==NOT_A_PORT) ) return -2;  // Arduino PCB pin canNOT be used to scan the keyboard.

  for (bitpos = 0; (ArdPortPinMask != 0x1); ++bitpos) { ArdPortPinMask >>= 1 ; }
  ArdPAM->bit = bitpos;    // Index of the bit position, corresponding to  'ArdPin', inside respective AVR microcontroller port.

  return 0;
}

#endif  // DIGITALPINMAP_H
