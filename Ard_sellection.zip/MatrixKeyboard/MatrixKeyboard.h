#ifndef MATRIXKEYBOARD_h
#define MATRIXKEYBOARD_h

/*----  Parameters that may be adjusted (with some limits) to attend user's desired behavior.  ----*/

// Considering a typing speed of a professional with 800 character per second, the maximum time
// to "KbPS_deactive" step to "KbPS_interval" step, with a single click ("KbPT_short" press type)
// would stand for 75 mili seconds.

#define KbScn_tick (7)                   // Time interval (in mili seconds) between consecutive scans. (Each scan checks all keys.) May be used as interval to an timer/counter interrupt handle.
static uint8_t const kbScanBuffer = (4); // Maximum number of keys that may be monitored simultaneously.
static uint8_t const kbHitBuffer = (10); // Maximum number of key presses that can be logged before lost any information.
#define KbScn_debouncefilter  (1u)       // Time interval (in "KbScn_tick" units) required between the scan detect an active/deactive key change (by its first time in a single press) and confirm this key change, so filtering the key bounces.
#define KbScn_longthreshold (35u)        // Maximum time interval (in "KbScn_tick" units) in which a single click step will be considered a SHORT click instead of a LONG click.
#define KbScn_longrepetition (10u)       // Time interval (in "KbScn_tick" units) allowed inside a double click press, between the first click ends and the second click start.

/*------------------------------------------------------------------------*/


/*----  Parameters that must change according the keyboard and Microcontroller hardwares.  ----*/

#define KbScanWriter (4)          // Number of Output pins that will power Vcc to the rows(or columns) of the matrix keyboard creating the scan rows(or columns) swap.
#define KbScanReader (4)          // Number of Input pins that will receive the power from scan rows(or columns) swap through activate keys of the matrix keyboard.
#define KbActiveValue (0x0)       // Value in the Input (ScanReader) pin of an active (pressed) keys when its rows(or columns) is selected (powered with KbSelectWriterValue). Set "0x1" for HIGH or "0" for LOW voltage level.
#define KbSelectWriterValue (0x0) // Value in the Output (ScanWriter) pin that will provide through an activated (pressed) key an respective Input (ScanReader) pin level change to KbActiveValue . Set "0x1" for HIGH or "0" for LOW voltage level.
#define KbReaderPullup (1)        // If this flag value is "1" all Input (ScanReader) pin will have its input pull-up resistor enabled.
// --- Future use key combination ---  #define KbCombKeys (4)        // Number of keys that must be checked for combination If this flag value is "1" all Input (ScanReader) pin will have its input pull-up resistor enabled.

static const uint8_t KbReaders[KbScanReader] = { 4,  5,  6,  7}; // Arduino Digital pin index that will be used as KbScanReader.
static const uint8_t KbWriters[KbScanWriter] = {11, 10,  9,  8}; // Arduino Digital pin index that will be used as KbScanWriter.

// For 4x4 WaveShare Keypad:
//
//    Keypad pin k7, addresses the first column :  "1" , "4" , "7" , "ENT";
//    Keypad pin k6, addresses the second column:  "2" , "5" , "8" , "0";
//    Keypad pin k5, addresses the third column :  "3" , "6" , "9" , "ESC";
//    Keypad pin k4, addresses the fourth column:  "STOP" , "GO" , "LOCK" , "POWER";
//    Keypad pin k3, addresses the fourth row:  "ENT" , "0" , "ESC" , "POWER";
//    Keypad pin k2, addresses the third row :  "7" , "8" , "9" , "LOCK";
//    Keypad pin k1, addresses the second row:  "4" , "5" , "6" , "GO";
//    Keypad pin k0, addresses the first row :  "1" , "2" , "3" , "STOP";
//
//    Arduino pin 04 (PD4) : Keypad pin k7, as KbScanReader 0 (operating as Digital Input);
//    Arduino pin 05 (PD5) : Keypad pin k6, as KbScanReader 1 (operating as Digital Input);
//    Arduino pin 06 (PD6) : Keypad pin k5, as KbScanReader 2 (operating as Digital Input);
//    Arduino pin 07 (PD7) : Keypad pin k4, as KbScanReader 3 (operating as Digital Input);
//    Arduino pin 08 (PB0) : (cathod) diode (anode) : Keypad pin k3, as KbScanWriter 3 (operating as Digital Output);
//    Arduino pin 09 (PB1) : (cathod) diode (anode) : Keypad pin k2, as KbScanWriter 3 (operating as Digital Output);
//    Arduino pin 10 (PB2) : (cathod) diode (anode) : Keypad pin k1, as KbScanWriter 1 (operating as Digital Output);
//    Arduino pin 11 (PB3) : (cathod) diode (anode) : Keypad pin k0, as KbScanWriter 0 (operating as Digital Output);
//
//    In all KbScanWriter pins, a diode must be placed in series between Arduino pin (operating
//    as Digital Output) and the respective Keypad pin. The diodes polarization must be such
//    that allows current passing through them only when the respective KbScanWriter pin is
//    selected (only when its voltage level is equal to logic level 'KbSelectWriterValue' -
//    '0x0' to low (GND) voltage either '0x1' to high (Vcc) voltage - ). It will prevent a
//    short-circuit between KbScanWriter pins when two or more keys from the same KbScanReader
//    pin (operating as Digital Input) are pressed simultaneously.

static const char * KbCode[KbScanWriter][KbScanReader] = {
  { "1"    , "2"    , "3"    , "STOP" },
  { "4"    , "5"    , "6"    , "GO"   },
  { "7"    , "8"    , "9"    , "LOCK" },
  { "ENT"  , "0"    , "ESC"  , "Power"}
};

/*
// --- Future use key combination ---
typedef struct CombinationKey_ {
  static const uint8_t kwix;
  static const uint8_t krix;
} CombkeyId;

 static const CombkeyId CombKey[KbCombKeys] = {
  {  0,  3 }, {  1,  3 } , {  2,  3 } , {  3,  3 }
 }

*/

/*------------------------------------------------------------------------*/


#include "DigitalPinMap.h"


#if ( 2 * (KbScn_debouncefilter + 1) * KbScn_tick  >= 75 )
  #error "KbScn_debouncefilter must small enough to acommodate a typing speed of 800 characters per second ."
#endif
#if  !(KbScn_longthreshold > KbScn_debouncefilter)
  #error " KbScn_longthreshold must be greater than KbScn_debouncefilter ."
#endif
#if !(KbScn_longthreshold > KbScn_longrepetition)
  #error " KbScn_longthreshold must be greater than KbScn_longrepetition ."
#endif


/*----  Enum and Structs.   ----*/
enum PressType {
         KbPT_unpressed  = 0,    // Key not pressed.
         KbPT_short      = 1,    // Single click with SHORT duration
         KbPT_long       = 2,    // Single click with LONG duration
         KbPT_shortshort = 3,    // Double click with SHORT first step duration and SHORT second step duration.
         KbPT_shortlong  = 4,    // Double click with SHORT first step duration and LONG second step duration.
         KbPT_longshort  = 5,    // Double click with LONG first step duration and SHORT second step duration.
         KbPT_longlong   = 6     // Double click with LONG first step duration and LONG second step duration.
};

enum PressSteps {
         KbPS_deactive    = 0,   //  Key not pressed.
         KbPS_preactive   = 1,   //  Key activated, maybe just noise.
         KbPS_active      = 2,   //  Key activated confirmation.
         KbPS_preinterval = 3,   //  Key deactivated, maybe just noise.
         KbPS_interval    = 4,   //  Key deactivated confirmation.
         KbPS_prereactive = 5,   //  Key second click (in a double click) activated, maybe just noise.
         KbPS_reactive    = 6,   //  Key second click (in a double click) activated confirmation.
         KbPS_predeactive = 7    //  Key second click (in a double click) deactivated, maybe just noise.
                                 //  Key second click (in a double click) deactivated confirmation lead the key state to "KbPS_deactive".
};

typedef struct Keystatus_ {
  enum PressSteps step_;
  uint8_t WtIx;            //  the key's "KbdScanWriter" index.
  uint8_t RdIx;            //  the key's "KbdScanReader" index.
  uint16_t  Kticks;       //  Number of "KbScn_tick" elapsed since last step change.
  uint16_t  Kprevticks;   //  Number of "KbScn_tick" elapsed during all previous step. It is usefull if the noise triggers a step change, then when the algorithm get back to previous step, the "Kbticks" can be safely restored.
  uint8_t  Kbrepetition;  //  Number of times that "KbScn_longrepetition" has elapsed since "KbScn_longthreshold" has been expired in the first or in the second Long click (of double click).
} Kstat;

typedef struct KeyPress_ {
  uint8_t WtIx;            //  the key's "KbdScanWriter" index.
  uint8_t RdIx;            //  the key's "KbdScanReader" index.
  enum PressType type_;    //  The type of key press.
  uint16_t  repetition;    //  If "KbLongRepetitionON" flag is "1", this variable stores the amount of time the  Number of times that "KbScn_longrepetition"
                           //      has elapsed since "KbScn_longthreshold" has been expired in the first or in the second Long click (of double click).
 // --- Future use key combination ---  uint8_t KeyGroup;      // Bits of this Flag represents a single Combination Key (like Alt, Shift, etc). If a (non Combination) key is pressed when any Combination key remains still pressed, corresponding bit inthis Flag must be set.
} KPress;

/*------------------------------------------------------------*/


/*----  Global variables.   ----*/
ArdPinAddMap WtArdPinAddMap [KbScanWriter];  // Map of the addresses of registers and pinmask of Arduino PCB pins. To see relation of Arduino pins to chip pins see file "pins_arduino.h"
ArdPinAddMap RdArdPinAddMap [KbScanReader];  // Map of the addresses of registers and pinmask of Arduino PCB pins. To see relation of Arduino pins to chip pins see file "pins_arduino.h"

static volatile Kstat KbStatus[kbScanBuffer]; // Used to monitor key presses.
static volatile uint8_t KbStatusNumb;    // Total number of keys which its pressing is been monitored now.

static volatile KPress KbHits[kbHitBuffer]; // used to monitor key presses
static volatile uint8_t KbHitsNumb;    // Total number of key presses acummulated.

 // --- Future use key combination ---  static volatile uint8_t CombKeyActive; // The data type of this variable must has at least as  same size  = (0)

/*------------------------------*/


// Function Prototyping
int8_t  KbGetArdPinAddMap(void);
void    KbConfigMCU(void);
void    KbStatusResetBuffer(void);
void    KbHitsResetBuffer(volatile KPress *kpp = &KbHits[0], uint8_t numb = kbHitBuffer);
int8_t  KbInit(void);
void    KbStatusRemove(uint8_t idx);
int8_t  KbStatusInclude(uint8_t Wtidx, uint8_t Rdidx);
int8_t  KbHitsUpdate (uint8_t ix, enum PressType PrTp);
uint8_t KbRetrieveHits(volatile KPress * Khit, uint8_t *remain = 0x0U, uint8_t numb = 1U);
void    KbStatusUpdate(uint8_t ix, uint8_t kstt);
void    KbScanNow(void);


int8_t KbGetArdPinAddMap(void) {

  struct Ard_pin_dio_add_map *ArdPAMpt;
  int8_t ret=0;

  // Get address map for Arduino's PCB pins in "KbWriters[KbScanWriter]".
  ArdPAMpt = &WtArdPinAddMap[0];
  for (uint8_t k = 0; k < KbScanWriter; ++k, ++ArdPAMpt) {
    ret = ArdDIOPinToAddMap(KbWriters[k], ArdPAMpt);
    if (ret < 0) return ret;
  }

  // Get address map for Arduino's PCB pins in "KbReaders[KbScanReader]".
  ArdPAMpt = &RdArdPinAddMap[0];
  for (uint8_t k = 0; k < KbScanReader; ++k, ++ArdPAMpt) {
    ret = ArdDIOPinToAddMap(KbReaders[k], ArdPAMpt);
    if (ret < 0) return ret;
  }

  return 0;
}

void KbConfigMCU(void) {
  ArdPinAddMap const  * WtPinMap = &WtArdPinAddMap[0];
  for (uint8_t n = 0; n < KbScanWriter; ++n, ++WtPinMap){
    uint8_t maskWt = WtPinMap->bitmask;
    *(WtPinMap->ddr) |= maskWt;  // Set pin as output.
    if (KbSelectWriterValue == 0x1) { // Initialize output pin values.
      *(WtPinMap->port) &= ~maskWt;
    } else {
      *(WtPinMap->port) |= maskWt;
    }
  }

  ArdPinAddMap const  * RdPinMap = &RdArdPinAddMap[0];
  for (uint8_t n = 0; n < KbScanReader; ++n, ++RdPinMap){
    uint8_t maskRd = RdPinMap->bitmask;
    *(RdPinMap->ddr) &= ~maskRd;   // Set pin as input.
    if (KbReaderPullup == 1) {
      *(RdPinMap->port) |= maskRd;   // Activate pull-up resistor for input pin.
    }
  }

}

void KbStatusResetBuffer(void) {
  for (uint8_t n = 0; n < kbScanBuffer; ++n ){
     volatile Kstat* KeyStat = & KbStatus[n];
     KeyStat->step_ = KbPS_deactive;
     KeyStat->WtIx = ~0x0;  // = 0u;
     KeyStat->RdIx = ~0x0;  // = 0u;
     KeyStat->Kticks = 0u;
     KeyStat->Kprevticks = 0u;
     KeyStat->Kbrepetition = 0u;
  }
}

void KbHitsResetBuffer(volatile KPress *kpp, uint8_t numb){
  for (uint8_t n = 0; n < numb; ++n ){
  volatile KPress * KeyPrs = kpp + n ;

  KeyPrs->WtIx = ~0x0;  // = 0u ;
  KeyPrs->RdIx = ~0x0;  // = 0u ;
  KeyPrs->type_ =  KbPT_unpressed;
  KeyPrs->repetition = 0u ;
  }
}

int8_t KbInit(void) {
  int8_t mapped = KbGetArdPinAddMap();
  if (mapped) return -1;
  KbConfigMCU();
  KbStatusResetBuffer();
  KbHitsResetBuffer();
  return 0;
}

void KbStatusRemove(uint8_t idx) {
  volatile Kstat *KsttLast;
  volatile Kstat *KsttIx;

  KsttIx  =  &KbStatus[idx];

  /* force the setup loop work like an interrupt handling that accept no nested interruption. */
  uint8_t StatusReg = SREG;    // Copy Status Register content to a local variable.
  cli();   //   Disable Global Interrupt Flag in Status Register, disabling any interrupt.

  if (KbStatusNumb > 1) {
    KsttLast  =  &KbStatus[KbStatusNumb-1];

    KsttIx->step_       = KsttLast->step_;
    KsttIx->WtIx        = KsttLast->WtIx;
    KsttIx->RdIx        = KsttLast->RdIx;
    KsttIx->Kticks      = KsttLast->Kticks;
    KsttIx->Kprevticks  = KsttLast->Kprevticks;
    KsttIx->Kbrepetition = KsttLast->Kbrepetition;
  } else {
    KsttLast  =  &KbStatus[0];
  }

  KsttLast->step_       = KbPS_deactive;
  KsttLast->WtIx        = ~0x0;
  KsttLast->RdIx        = ~0x0;
  KsttLast->Kticks      = 0u;
  KsttLast->Kprevticks  = 0u;
  KsttLast->Kbrepetition = 0u;

  if (KbStatusNumb > 0) --KbStatusNumb;

  /* enable interrupts and restore Status Register original contents  */
  sei();   // Enable Global Interrupt Flag in Status Register, enabling any previous enabled interrupt.
  SREG = StatusReg;

}

int8_t KbStatusInclude(uint8_t Wtidx, uint8_t Rdidx) {
  volatile Kstat *KsttLast;
  if (KbStatusNumb >= kbScanBuffer) {
    return -1;  // All items of "KbStatus[]" is already been used;
  }

  KsttLast  =  &KbStatus[KbStatusNumb];

  /* force the setup loop work like an interrupt handling that accept no nested interruption. */
  uint8_t StatusReg = SREG;    // Copy Status Register content to a local variable.
  cli();   //   Disable Global Interrupt Flag in Status Register, disabling any interrupt.

  KsttLast->step_       = KbPS_preactive;
  KsttLast->WtIx        = Wtidx;
  KsttLast->RdIx        = Rdidx;
  KsttLast->Kticks      = 0u;
  KsttLast->Kprevticks  = 0u;
  KsttLast->Kbrepetition = 0u;

  ++KbStatusNumb;

  /* enable interrupts and restore Status Register original contents  */
  sei();   // Enable Global Interrupt Flag in Status Register, enabling any previous enabled interrupt.
  SREG = StatusReg;

  return 0;
}

int8_t KbHitsUpdate (uint8_t ix, enum PressType PrTp) {

  volatile Kstat *KeyStt;
  volatile KPress *KeyHit ;

  KeyStt = &KbStatus[ix];

  if (KbHitsNumb > 0)  KeyHit = &KbHits[KbHitsNumb-1];

  if ( (KbHitsNumb > 0) && (KeyHit->WtIx == KeyStt->WtIx) && (KeyHit->RdIx == KeyStt->RdIx) &&
       (KeyHit->type_ == PrTp) ) {  // Check if actual pressed key and its PressType is the same as the last pressed key.
      KeyHit->repetition += KeyStt->Kbrepetition;
      KeyStt->Kbrepetition = 0;
  } else {  // New hit for new key.
    if (KbHitsNumb >= kbHitBuffer) {
      return -1;   // Buffer "KbHits[kbHitBuffer]" is full.
    }
    KeyHit = &KbHits[KbHitsNumb];

    KeyHit->WtIx = KeyStt->WtIx;
    KeyHit->RdIx = KeyStt->RdIx;
    KeyHit->type_ = PrTp;
    KeyHit->repetition = KeyStt->Kbrepetition;
    KeyStt->Kbrepetition = 0;

    ++KbHitsNumb;
  }
  return 0;
}

uint8_t KbRetrieveHits(volatile KPress * Khit, uint8_t *remain, uint8_t numb) {
  uint8_t ix;
  volatile KPress *KeyHit, *KeyHit2;
  if (Khit == 0x0) {   // Invalid "output" buffer.
    if (remain != 0x0) *remain = KbHitsNumb;
    return 0U;
  }
  if (KbHitsNumb == 0U) {  // Buffer "KbHits[kbHitBuffer]" is empty.
    if (remain != 0x0) *remain = KbHitsNumb;
    return 0U;
  }
  if (numb == 0U) {  // Required retrieves number is zero.
    if (remain != 0x0) *remain = KbHitsNumb;
    return 0U;
  }

  if (numb > KbHitsNumb) numb = KbHitsNumb;  // Set the maximum number of possible retrieves.

    //** Copy data from "KbHits[kbHitBuffer]" to output buffer.
  KeyHit = &KbHits[0];
  for (ix = 0; ix < numb; ++ix, ++Khit, ++KeyHit) {

    Khit->RdIx = KeyHit->RdIx;
    Khit->WtIx = KeyHit->WtIx;
    Khit->repetition = KeyHit->repetition;
    Khit->type_ = KeyHit->type_;
    // --- Future use key combination ---  Khit->KeyGroup = KeyHit->KeyGroup;

  }

    //** Copy data from higher index items of "KbHits[kbHitBuffer]" to lower index items data space.
  if (numb < KbHitsNumb) {  // Remove data copied from "KbHits[kbHitBuffer]";
    KeyHit  = &KbHits[0];
    KeyHit2 = &KbHits[numb];
    for (ix = 0; (numb + ix) < KbHitsNumb; ++ix, ++KeyHit, ++KeyHit2 ) {

      // Transfer data from higher index to lower index.
      KeyHit->RdIx       = KeyHit2->RdIx;
      KeyHit->WtIx       = KeyHit2->WtIx;
      KeyHit->repetition = KeyHit2->repetition;
      KeyHit->type_      = KeyHit2->type_;
      // --- Future use key combination ---  KeyHit->KeyGroup = KeyHit2->KeyGroup;

    }
  }

    //** Clear data space of higher index items of "KbHits[kbHitBuffer]".
  if (numb <= KbHitsNumb) {  // Remove data copied from "KbHits[kbHitBuffer]";
    ix = KbHitsNumb - numb;
    KeyHit  = &KbHits[ix];
    for (; ix < KbHitsNumb; ++ix, ++KeyHit ) {

      // Clear data from higher index
      KeyHit->WtIx = ~0x0;
      KeyHit->RdIx = ~0x0;
      KeyHit->type_ = KbPT_unpressed;
      KeyHit->repetition = 0u;
      // --- Future use key combination ---  KeyHit->KeyGroup = 0x0u;

    }
  }

  KbHitsNumb -= numb;
  if (remain != 0x0) *remain = KbHitsNumb;

  return numb;
}

void KbStatusUpdate(uint8_t ix, uint8_t kstt) {

  const uint16_t shortToLongThreshold  =  KbScn_longthreshold - KbScn_longrepetition ;
  volatile Kstat *KeySttUpDt  = &KbStatus[ix];
  enum PressSteps kstep = KeySttUpDt->step_;
  uint16_t ktck= KeySttUpDt->Kticks + 1;  // This code line work fine if the function "KbScanNow" runs in standard interval defined by "KbScn_tick" macro. This may be acomplished by timer interrupt.

  /*** STEP :  KbPS_preactive ***/
  if ( kstep == KbPS_preactive) {    //  Key activated, maybe just noise.
    if (ktck >= KbScn_debouncefilter) {
      if (kstt == 1) {    //  Key still pressed.
        //--- Future use key combination ---  If ( IsCombinationKey(KeySttUpDt->WtIx , KeySttUpDt->RdIx) ) { } elseif {
        KeySttUpDt->step_ = KbPS_active;
        KeySttUpDt->Kticks = 0;
        // KeySttUpDt->Kprevticks = 0;
        KeySttUpDt->Kbrepetition = 1;
        KbHitsUpdate(ix, KbPT_short);
        //--- Future use key combination ---  }
      } else {  // Previous detection of "active state" was caused by noise.
        KbStatusRemove(ix); // Clear actual fake key press to state "KbPS_deactive".
      }
    } else {    // if (ktck < KbScn_debouncefilter)
      KeySttUpDt->Kticks = ktck;
    }


  /*** STEP :  KbPS_active ***/
  } else if ( kstep == KbPS_active) {   //  Key activated confirmation.
    if (kstt == 1) {    //  Key still pressed.
      if ( (ktck >= shortToLongThreshold) && ( (ktck - shortToLongThreshold) >= KbScn_longrepetition ) ) {  // Long click.
        KeySttUpDt->Kbrepetition += 1;  // When a key hit become a long click, variable "KbStatus[ix].Krepetition" must always be updated using its actual value to avoid possibility of a HitCheck clears previous repetition values of a still active long click.
            // KeySttUpDt->Krepetition += (ktck - KbScn_longthreshold) / KbScn_longrepetition;  // When a key hit become a long click, variable "KbStatus[ix].Krepetition" must always be updated using its actual value to avoid possibility of a HitCheck clears previous repetition values of a still active long click.
        KeySttUpDt->Kticks = ktck - KbScn_longrepetition;  //  After a key hit become a long click, variable "KbStatus[ix].Kticks" does NOT need count absolute time (in key board scan units, "KbScn_tick"), just need to allow identification of new key repetitions (while key is still pressed).
            // KeySttUpDt->Kticks = ktck - KbScn_longrepetition * KbStatus[ix].Krepetition;  //  After a key hit become a long click, variable "KbStatus[ix].Kticks" does NOT need count absolute time (in key board scan "KbScn_tick"), just need to allow identification of new key repetitions (while key is still pressed).
        KbHitsUpdate(ix, KbPT_short);   // The PressType must be kept at "KbPT_short" value.
      } else {
        KeySttUpDt->Kticks = ktck;
      }
    } else {    // Key released (or deactivation caused by noise).
      KeySttUpDt->step_ = KbPS_predeactive;
      KeySttUpDt->Kticks = 0;
      KeySttUpDt->Kprevticks = ktck;
      //  Variable "KbStatus[ix].Krepetition" must not be changed to allow possible roll-back.
    }


  /*** STEP :  KbPS_predeactive ***/
  } else if ( kstep == KbPS_predeactive) {   //  Key deactivated, maybe just noise.
    if (ktck >= KbScn_debouncefilter) {   // Start next Press Step.
      if (kstt == 0) {    //  Key was released.
        KbStatusRemove(ix); // Clear actual fake key press to state "KbPS_deactive".
      } else {  // Previous detection of "deactive state" was caused by noise.
        KeySttUpDt->step_ = KbPS_active;
        KeySttUpDt->Kticks = ktck + KeySttUpDt->Kprevticks;
        KeySttUpDt->Kprevticks = 0;
      }
    } else {    // if (ktck < KbScn_debouncefilter)
      KeySttUpDt->Kticks = ktck;
    }
  }

}

void KbScanNow(void) {

  ArdPinAddMap const  * WtPinMap;
  ArdPinAddMap const  * RdPinMap;
  uint8_t bitIx, bitVal, WtBitmask;

  volatile Kstat *KeyStt;

    //** Scan keys already monitored in "KbStatus[KbStatusNumb]" to update its status.
  KeyStt = &KbStatus[0];
  for (int k = 0; k < KbStatusNumb; ++k, ++KeyStt) {
    uint8_t Rx, Wx;
    if (KeyStt->step_ == KbPS_deactive) break; // If an item in 'KbStatus' has parameter "step_" value equals to "KbPS_deactive" (which means no key press stored in that item) all following itens also has the same value.
    Wx = KeyStt->WtIx;
    Rx = KeyStt->RdIx;
        // Activate a row(or column) in the matrix keyboard to look for a key pressed (in corresponding row or column).
    WtPinMap = &WtArdPinAddMap[Wx];
    WtBitmask  = WtPinMap->bitmask;
    if (KbSelectWriterValue == 0x1) {   // Set output (ScanWriter) pin value to scan corresponding ("KbWriters[kw]") row(or column) in the matrix keyboard.
      *(WtPinMap->port) |= WtBitmask;
    } else {
      *(WtPinMap->port) &= ~WtBitmask;
    }


    // Scan the state of a specific key in selected row(or column) for a update its status.
    RdPinMap = &RdArdPinAddMap[Rx];
    bitIx = RdPinMap->bit;
    bitVal = ( (*(RdPinMap->pin)) >> bitIx ) & 0x1u;
    if ( bitVal == KbActiveValue){  // The is active (pressed).
      // Update status for key [kw][kr] in active state.
      KbStatusUpdate(k, 1);
    } else {  // The is deactive (unpressed).
      // Update status for key [kw][kr] in deactive state.
      KbStatusUpdate(k, 0);
    }

    // Deactivate selected row(or column) in the matrix keyboard .
    if (KbSelectWriterValue == 0x1) {       // Clear output (ScanWriter) pin value to unselect corresponding ("KbWriters[kw]") row(or column) in the matrix keyboard.
      *(WtPinMap->port) &= ~WtBitmask;
    } else {
      *(WtPinMap->port) |= WtBitmask;
    }

  }

    //** Scan all keys looking for new pressed key not monitored in "KbStatus[KbStatusNumb]" yet.
  KeyStt = &KbStatus[0];
  for (int kw = 0; kw < KbScanWriter; ++kw){
    WtPinMap = &WtArdPinAddMap[kw];
    WtBitmask  = WtPinMap->bitmask;
    if (KbSelectWriterValue == 0x1) {   // Set output pin value to select actual ("KbWriters[kw]") ScanWriter row(or column) for scan.
      *(WtPinMap->port) |= WtBitmask;
    } else {
      *(WtPinMap->port) &= ~WtBitmask;
    }

        // Check for new "preactivated" keys .
        for (int kr = 0; kr < KbScanReader; ++kr) {
          RdPinMap = &RdArdPinAddMap[kr];
          bitIx = RdPinMap->bit;
          bitVal = ( (*(RdPinMap->pin)) >> bitIx ) & 0x1u;
          if ( bitVal == KbActiveValue){
            uint8_t ix;
            // Look for key [kw][kr] hit in progress at "KbStatus[kbScanBuffer]".
            KeyStt = &KbStatus[0];
            for ( ix = 0 ; (ix < KbStatusNumb) && ((KeyStt->WtIx != kw) || (KeyStt->RdIx != kr)); ++ix, ++KeyStt );
            // Discard key already monitored by in buffer "KbStatus[kbScanBuffer]".
            if (ix == KbStatusNumb) {
              KbStatusInclude(kw, kr);
            }
          }
        }

    if (KbSelectWriterValue == 0x1) {       // Clear output pin value to unselect actual ("KbWriters[kw]") ScanWriter row(or column).
      *(WtPinMap->port) &= ~WtBitmask;
    } else {
      *(WtPinMap->port) |= WtBitmask;
    }

  }

}


#endif  // MATRIXKEYBOARD_h
