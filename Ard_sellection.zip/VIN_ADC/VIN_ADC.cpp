#include <avr/interrupt.h>
#include <avr/boot.h>
    // If Single Conversion Mode with Noise Canceler is used, an ADC Conversion Complete Interrupt handling routine must be defined.
    // If Free Running Mode is used, to easy access of ADC conversion output, an ADC Conversion Complete Interrupt handling routine may be defined.


//>>>>>>>>>>>>>>>>> AVR ATmega 328P  -  ANALOG TO DIGITAL CONVERSOR  <<<<<<<<<<<<<<<<<<<<<<<//
// ---------DESCRIPTION :
//--- The Analog to Digital Converter - ADC of AVR ATmega328PP ---//
//    The AVR ATmega328PP has a single ADC converter which input signal is multiplexed
//    to one of the six external (analog) input pins or three internal refernces: GND,
//    Banbgap Voltage (V_Bg = 1.1V) and microcontroller's Teperature Sensor .
//    The ADC is implemented as a successive approximation circuitry. A reference voltage
//    V_REF powers a 10 bit Digital to Analog Converter that supplies a fraction of V_REF
//    voltage to one input of an Analog Comparator. The voltage supplied to the other input
//    of  the Analog Comparator is the selected analog input signal. Depending on the
//    comparision result, the Conversion Logic will set or clear the next least significant
//    bit of the ADC and try another analog comparision.
//    The Conversion Logic circuit receives clock input from a prescaler. A normal conversion
//    takes 13 ADC clock cycles (from the prescaler). The first conversion after the ADC is
//    switched on (ADEN in ADCSRA is set) takes 25 ADC clock cycles in order to initialize
//    the analog circuitry. When the bandgap reference voltage is used as input to the ADC,
//    it will take a certain time for the voltage to stabilize.
//    When a conversion is complete, the result is written to the ADC data registers,
//    and ADIF is set. In single conversion mode, ADSC is cleared simultaneously. When auto
//    triggering mode is used, the prescaler is reset when trigger event (rising edge of the
//    Microcontroller's Analog Comparator, External Interrupt Request, Timer/Counter0 Match A,
//    Timer/Counter0 Overflow, Timer/Counter1 Match B, Timer/Counter1 Overflow) occurs. This
//    assures a fixed delay from the trigger event to the start of conversion: two ADC clock
//    cycles plus three additional CPU clock cycles after the rising edge on the trigger source
//    signal. In free running mode, a new conversion will be started immediately after the
//    conversion completes, while ADSC remains high.
//    To change the selection of analog input signal or V_REF, ADMUX register can be safely
//    updated in the following ways: a) when ADATE or ADEN is cleared; b) (if a conversion is
//    in progress) one ADC clock cycle after the trigger event and during conversion (or ADSC
//    is written); c) After a conversion, before the Interrupt Flag used as trigger source
//    is cleared.
//
//--- Apply voltage at AREF pin ---//
//    GND pin voltage must be the lowest value at analog inputs and the voltage applied to
//    V_REF must be the greatest value applied to analog inputs. The conversiont span of
//    the ADC (coded) output is from GND to V_REF (minus 1 LSB). The V_REF can be selected
//    as either: A_VCC, internal 1.1V reference, or external AREF pin.
//    If A_VCC or internal 1.1V reference is selected as V_REF, A_REF pin must be connected
//    to a capacitor, and this capacitor connected to GND, to increase noise immunety.
//    If a fixed voltage source is connected to A_REF pin, other reference voltage options
//    should NOT be applied, as they (A_VCC or 1.1V) will be shorted to the external source.
//    The first ADC conversion result after switching reference voltage source may be
//    inaccurate, and the user is advised to discard this result.
//    A_VCC must not differ more than �0.3V from VCC.
//
//--- ADC Noise Canceler ---//
//    To cancel noise from CPU core and peripherals, the conversion is made in sleep mode
//    using Single Conversion Mode.
//    To use this option is required:
//      * ADC is enabled and not busy converting (and not in free running mode);
//      * Single Conversion mode must be selected;
//      * the ADC Conversion Complete interrupt must be enabled;
//      * Enter ADC Noise Reduction mode (or Idle mode);
//   Once the CPU has been halted, ADC will start a conversion. And any interrupt can
//   wake up CPU. When conversion is complete, ADC Conversion Complete interrupt will be
//   generated and its interrupt handle executed. If another interrupt is generated,
//   CPU will remain in active mode until a new sleep command is executed.
//   Note that ADC will not be automatically turned off when entering other sleep modes
//   than idle mode and ADC noise reduction mode. To avoid excessive power consumption in
//   such sleep modes, write zero to ADEN before entering them.
//
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<//



#include "VIN_ADC.h"

// * - * - * - * - * - * -    GLOBAL VARIABLES DEFINITION  - * - * - * - * - * - * - * - * //

//--- ADC Voltage Reference V_REF constants ---//
//    A default option for V_REF is set to ADC_VREF_AREF to prevent any short circuit between a possible
//    voltage source at A_REF pin and any internal sources references (A_VCC and 1.1V).
const uint8_t ADC_VREF_AREF = 1u;   // V_REF is attached to external voltage source at A_REF pin (all internal options A_VCC and 1.1V must be turned off):(REFS1=0, REFS0=0)
const uint8_t ADC_VREF_AVCC = 2u;   // V_REF is attached to internal A_VCC (but hardware must has an external capacitor between A_REF pin and GND): (REFS1=0, REFS0=1);
const uint8_t ADC_VREF_VBg =  3u;   // V_REF is attached to internal 1.1V V_Bandgap (but hardware must has an external capacitor between A_REF pin and GND): (REFS1=1, REFS0=1);

//--- Quantization Level (10-bit or 8-bit) constants ----//
const uint8_t ADC_QuantizLev_8bit =  8u;  // Output of ADC can be accessed with  just a single read at ADCH register, but only 8 MSB are present there.
const uint8_t ADC_QuantizLev_10bit = 10u;  // Output of ADC can be accessed with two registers read: ADCH (with 2 MSB)  and ADCL (with 8 LSB).

//--- Analog Input channel constants ---//
const uint8_t ADC_Ainp_A0 =  0u;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
const uint8_t ADC_Ainp_A1 =  1u;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
const uint8_t ADC_Ainp_A2 =  2u;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
const uint8_t ADC_Ainp_A3 =  3u;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
const uint8_t ADC_Ainp_A4 =  4u;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
const uint8_t ADC_Ainp_A5 =  5u;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
const uint8_t ADC_Ainp_TempSensor = 8u;  // AVR ATmega328P internal Temperature Sensor is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
const uint8_t ADC_Ainp_VBg = 14u;  // AVR ATmega328P internal Bandgap 1.1V is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
const uint8_t ADC_Ainp_GND = 15u;  // AVR ATmega328P internal GND is selected by Input Multiplexer as its output to the analog comparator input of the ADC.

//--- ADC modes: Single Conversion and AutoTrigger sources constants ---//
const uint8_t ADC_ModeAutoTrig_Free        = 0u;    // For Free Running Mode (start a new conversion as soon as the currently one finishes.)
const uint8_t ADC_ModeAutoTrig_AComp       = 1u;    // For ARDUINO Analog Comparator Circuit.
const uint8_t ADC_ModeAutoTrig_ExtIRQ      = 2u;    // For ARDUINO PCB pin 3 (AVR ATmega328P: pin 5, PD3, INT1).
const uint8_t ADC_ModeAutoTrig_Tmr0MatchA  = 3u;    // For ARDUINO Timer/Counter0 Compare Match A (interrupt flag bit).
const uint8_t ADC_ModeAutoTrig_Tmr0OvFlow  = 4u;    // For ARDUINO Timer/Counter0 Overflow (interrupt flag bit).
const uint8_t ADC_ModeAutoTrig_Tmr1MatchB  = 5u;    // For ARDUINO Timer/Counter1 Compare Match A (interrupt flag bit).
const uint8_t ADC_ModeAutoTrig_Tmr1OvFlow  = 6u;    // For ARDUINO Timer/Counter1 Overflow (interrupt flag bit).
const uint8_t ADC_ModeAutoTrig_Tmr1CapEvnt = 7u;    // For ARDUINO Timer/Counter1 Capture Event (interrupt flag bit).
const uint8_t ADC_ModeSingleConv           = 16u;


volatile _ADC_Out_DT_  ADC_Out_Buf_circ[(_Circular_Buffer_Size_ < 2u)? 2u : _Circular_Buffer_Size_]; // Buffer used by ADC Conversion Complete Interrupt handling routine.
volatile uint16_t ADC_Out_Buf_circ_BEG;   // This is the index of "ADC_Out_Buf_circ[]" array, from where the next ADC conversion output will be
                                          //     extracted by the "main()" routine (with or with out overlap).
                                          //     An overlap occur when the ADC conversion output saved into circular buffer "ADC_Out_Buf_circ"
                                          //     (by ADC Conversion Complete Interrupt handling routine) starts to rewritten the oldest ones.

volatile uint16_t ADC_Out_Buf_circ_END;   // This is the index of "ADC_Out_Buf_circ[]" array, to where the next ADC conversion output will be
                                          //     saved by ADC Conversion Complete Interrupt handling function (with or with out overlap).

volatile uint16_t ADC_Out_Buf_circ_TOT;   // Number of ADC conversion output that has NOT been extracted from "main()" routine (with or with
                                          //     out overlap). If "ADC_Out_Buf_circ_TOT" value is greater than "_Circular_Buffer_Size_", then
                                          //     an overlap occurred.

volatile uint8_t ADC_Quantiz_bef_TempSensor;    //  Save the quantization level used before call any function related to internal microcontroller
                                                //     Temperature Sensor, so it could be stored after read the internal  temperature.

// * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * //





bool ADC_ADMUX_OKtoChange(void) {
  bool IsOk = 0;
  if (!(ADCSRA &(1 << ADEN)) ) {     // The ADC is turned off.
    IsOk = true;
  } else if (!(ADCSRA &(1 << ADATE)) &&   // The ADC is operating in Single Conversion Mode.
             !(ADCSRA & (1 << ADSC)) ) {  // No conversion is in progress.
                                          // The ADSC bit will be read as one during a conversion, independently of how the conversion was started.
                                          //     It can be used to determine if a conversion is in progress.
    IsOk = true;
  } else if ((ADCSRA &(1 << ADATE)) &&    // The ADC is operating in Auto trigger Conversion Mode.
             !(ADCSRA & (1 << ADSC)) ) {  // No conversion is in progress.
                                          // The ADSC bit will be read as one during a conversion, independently of how the conversion was started.
                                          //     It can be used to determine if a conversion is in progress.
    IsOk = true;
  }
  return IsOk;
}

int8_t ADC_VREF_Select(uint8_t refer ) {
  // ONLY use "ADC_VREF_Select()" IN ADC INITIALIZATION, because it does NOT check if the change may be done without interfer in a conversion that may be in progress.
  // AFTER initialization, the function "ADC_VREF_Change()" shall be used, if necessary.

  if (refer == ADC_VREF_AVCC) {
    ADMUX &= ~(1 << REFS1);
    ADMUX |= (1 << REFS0);
  } else if (refer == ADC_VREF_VBg){
    ADMUX |= (1 << REFS1) | (1 << REFS0);
  } else if (refer == ADC_VREF_AREF){
    ADMUX &= ~((1 << REFS1) | (1 << REFS0));
  } else {  //  including the default option (ADC_VREF_AREF) that prevents any short circuit from A_REF pin to internal sources references (A_VCC and 1.1V).
    ADMUX &= ~((1 << REFS1) | (1 << REFS0));
    return -1;
  }
  return 0;
}

int8_t ADC_VREF_Change(uint8_t refer ) {
  // This function may be used after ADC initialization. Do NOT use "ADC_VREF_Select()" AFTER initialization", because it does NOT check if the change may be done without interfer in a conversion that may be in progress.

  if (ADC_ADMUX_OKtoChange()) {
    return ADC_VREF_Select(refer);
  } else {
    return -1;
  }
}

int8_t ADC_QuantizationLevel(uint8_t lev) {
  // ONLY use "ADC_QuantizationLevel()" IN ADC INITIALIZATION, because it does NOT check if the change may be done without interfer in a conversion that may be in progress.
  // AFTER initialization, the function "ADC_Quantization_Change()" shall be used, if necessary.
  if (lev == ADC_QuantizLev_8bit){
    ADMUX |= (1 << ADLAR);    // For 8 bit conversion result, turn on "left adjustment": (ADLAR=1).
  } else if (lev == ADC_QuantizLev_10bit) {
    ADMUX &= ~(1 << ADLAR);   // For 10 bit conversion result, let default "right adjustment": (ADLAR=0).
  } else {
    return -1;
  }
  return 0;
}

int8_t ADC_Quantization_Change(uint8_t lev) {
  // This function may be used after ADC initialization. Do NOT use "ADC_QuantizationLevel()" AFTER initialization", because it does NOT check if the change may be done without interfer in a conversion that may be in progress.

  if (ADC_ADMUX_OKtoChange()) {
    return ADC_QuantizationLevel(lev);
  } else {
    return -1;
  }
}

int8_t ADC_Input_Select(uint8_t inp) {
  // ONLY use "ADC_Input_Select" IN ADC INITIALIZATION, because it does NOT check if the change may be done without interfer in a conversion that may be in progress.
  // AFTER initialization, the function "ADC_Input_Change" shall be used, if necessary.

  if (inp == ADC_Ainp_A0) {
    ADMUX &= ~((1 << MUX3)|(1 << MUX2)|(1 << MUX1)|(1 << MUX0));
  } else if (inp == ADC_Ainp_A1) {
    ADMUX &= ~((1 << MUX3)|(1 << MUX2)|(1 << MUX1));
    ADMUX |= (1 << MUX0);
  } else if (inp == ADC_Ainp_A2) {
    ADMUX &= ~((1 << MUX3)|(1 << MUX2)|(1 << MUX0));
    ADMUX |= (1 << MUX1);
  } else if (inp == ADC_Ainp_A3) {
    ADMUX &= ~((1 << MUX3)|(1 << MUX2));
    ADMUX |= (1 << MUX1)|(1 << MUX0);
  } else if (inp == ADC_Ainp_A4) {
    ADMUX &= ~((1 << MUX3)|(1 << MUX1)|(1 << MUX0));
    ADMUX |= (1 << MUX2);
  } else if (inp == ADC_Ainp_A5) {
    ADMUX &= ~((1 << MUX3)|(1 << MUX1));
    ADMUX |=  (1 << MUX2)|(1 << MUX0);
  } else if (inp == ADC_Ainp_TempSensor) {
    ADMUX &= ~((1 << MUX2)|(1 << MUX1)|(1 << MUX0));
    ADMUX |=  (1 << MUX3);
  } else if (inp == ADC_Ainp_VBg) {
    ADMUX &= ~(1 << MUX0);
    ADMUX |=  (1 << MUX3)|(1 << MUX2)|(1 << MUX1);
  } else if (inp == ADC_Ainp_A5) {
    ADMUX |=  (1 << MUX3)|(1 << MUX2)|(1 << MUX1)|(1 << MUX0);
  } else {
    return -1;
  }
  return 0;
}

int8_t ADC_Input_Change(uint8_t inp) {
  // This function may be used after ADC initialization. Do NOT use "ADC_Input_Select" AFTER initialization", because it does NOT check if the change may be done without interfer in a conversion that may be in progress.

  if (ADC_ADMUX_OKtoChange()) {
    return ADC_Input_Select(inp);
  } else {
    return -1;
  }
}

int8_t ADC_Input_SetTemperatureSensor (void) {
  //
  //  >>>> WARNING  * * *  WARNING  * * *  WARNING  * * *  WARNING  * * *  WARNING <<<<
  //
  //  >>>> WARNING :  to use internal Temperature Sensor, A_REF pin mustNOT be connected to
  //  >>>>            any external source, but only to a capacitor (100nF) which opposite
  //  >>>>>>>>        terminal already connected to GND.

  // NOTE: if preprocessor macro "_Quantization_Level_" was defined as "( ADC_QuantizLev_8bit )"
  //       at compilation time, the ADC conversion output buffer "ADC_Out_Buf_circ[]" will be
  //       reinitialized. Old conversion outputs (not extracted) may be lost.


  int8_t ret;
  if (ADC_ADMUX_OKtoChange()) {
    ret = ADC_VREF_Select(ADC_VREF_VBg);    // V_REF must be set as Bandgap Voltage (1.1V).
    ADC_Quantiz_bef_TempSensor = ADMUX & (1 << ADLAR);   // Save the quantization level in which conversion output buffer "ADC_Out_Buf_circ[]" was created for. For 10 bit conversion, ADLAR=0.
    if (!ret) ADC_QuantizationLevel(ADC_QuantizLev_10bit);  // Resolution of conversion output must be 10 bits.
    if (!ret) ret = ADC_Input_Select(ADC_Ainp_TempSensor); // Internal Temperature Sensor must be selected as analog mux output.
    if (!ret) ret = ADC_Mode_Set_SingleConv(1u);   // Operation Mode must be set to Single Conversion Mode.
    if (!ret) ADC_Conversion_DiscardFirst();    //  The internal Bandgap voltage reference takes sometime to achieve its 1.1V . Using it before achiev 1.1V will result in iorrect reads.
//    if ( (!ret) && (sizeof(_ADC_Out_DT_) == sizeof (uint16_t)) ) {
//      // NOTE: if preprocessor macro "_Quantization_Level_" was defined as "( ADC_QuantizLev_8bit )" at compilation time,
//      // the ADC conversion output buffer "ADC_Out_Buf_circ[]" must be reinitialized, so the variable "ADC_Out_Buf_circ_BEG"
//      // can point to the next conversion output instead of an old not extracted output. Old conversion outputs (not
//      // extracted) may be lost.
//      ADC_ISR_Initialize(); //
//    }
  } else {
    return -1;
  }

  return ret;
}

int8_t ADC_Read_TeperatureSensor(int16_t *temp_celsius, uint8_t noisecanceler, uint16_t * adc_output) {

// >>>> * * * WARNING  * * *  WARNING  * * *  WARNING  * * *  WARNING  * * *  WARNING  * * *  WARNING * * * <<<<<//
//    This function may give wrong values.
//  Without the correct address of internal Temperature Sensor TS_GAIN and TS_OFFSET, stored in EEPROM memory while in 
//  production tests, it is not possible to get the corrent temperature values. Manuals points to: TS_OFFSET (temp sensor 
//  offset) = 0x0002 and  TS_GAIN (temp sensor gain) =  0x0003. But TS_OFFSET address overlap device signature byte, and 
//  both TS_OFFSET and TS_GAIN seems to have values that does not give correct results.

  
  int8_t rtrn;
  uint16_t adc_conv_output;
  _ADC_Out_DT_ outcahce;

  rtrn = ADC_Quantization_Change(ADC_QuantizLev_10bit);
  if (rtrn) return rtrn;

  if (!noisecanceler) {
    rtrn = ADC_Conversion_Start();
    if (!rtrn) {  // Read ADC conversion output.
//      while (!(ADCSRA & (1 << ADIF)) ) { _NOP();  _NOP(); _NOP(); _NOP()};  // Wait until conversion is completed.
//      ADCSRA |= (1 << ADIF));   // Clear "ADIF" (ADC Conversion Complete Interrupt Flag) by writing a logical one to it, so another conversion may use it to check for conversion completeness.
      while (ADCSRA & (1 << ADSC)) { _NOP(); _NOP(); _NOP(); _NOP();};  // Wait until conversion is completed.
      adc_conv_output  = (ADCL);       // To ensure that the content of the data registers belongs to the same conversion, ADCL must be read first.
      adc_conv_output |= (ADCH << 8);  // A read in ADCL register blocks ADC access to data registers. A read in ADCH register realeases ADC access to data registers.
    }
  } else {
    // To grant that the variable "ADC_Out_Buf_circ_BEG" will point to the next conversion output,
    // instead of an old not extracted output, the ADC conversion output buffer "ADC_Out_Buf_circ[]"
    // shall be reinitialized. Thus, old conversion outputs (not extracted) may be lost.
    ADC_ISR_Initialize();

    rtrn =  ADC_Mode_SingleConvNoiseCancel_start();
            // The ADC conversion output from a Single Mode with Noise Canceler is saved to buffer "ADC_Out_Buf_circ[]"
            //     by ISR (Interrupt Service Routine). The ISR implemented in this library, as well as functions
            //     "ADC_outbuf_extract()" and "ADC_Read_TeperatureSensor" have their functionality integrated to deal
            //     with the case when preprocessor macro "_Quantization_Level_" is defined as "( ADC_QuantizLev_8bit )"
            //     at compilation time.
    if (!rtrn) {
      if (sizeof(_ADC_Out_DT_) == sizeof (uint8_t)) {   // Quantization level (resolution of ADC conversion output) was set to 8 bits at compilation time.
        rtrn = ADC_outbuf_extract(& outcahce, 0x1u, 0x0u);  // Read the least significant byte of the ADC conversion output "ADCL".
        if (!rtrn) {
          adc_conv_output = outcahce;  // Save the contents of  the least significant  byte of the ADC conversion output "ADCL".
          rtrn = ADC_outbuf_extract(& outcahce, 0x1u, 0x0u);  // Read the most significant byte of the ADC conversion output "ADCH".
          if (!rtrn) {
            adc_conv_output |= ((uint16_t)outcahce << 8u);   // Save the contents of  the least significant byte of the ADC conversion output "ADCH".
          }
        }
      } else {
        rtrn = ADC_outbuf_extract(&adc_conv_output, 0x1u, 0x0u);
      }
    }
  }
 if (!rtrn) {
   // uint8_t TS_gain = boot_signature_byte_get(0x0003)    // (0x0007);  The real address seems to remains undocumented.
   // int16_t TS_offset = boot_signature_byte_get(0x0002)  // (0x0005);  The real address seems to remains undocumented.
   uint8_t TS_gain = boot_signature_byte_get(0x0003);                    // This value is a try from a lot of possible combination of addresses for TS_GAIN and TS_OFFSET that returns in temperatures near real.
   int16_t TS_offset = (((uint16_t)boot_signature_byte_get(0x0006)) << 8) | boot_signature_byte_get(0x0007); // This value is a try from a lot of possible combination of addresses for TS_GAIN and TS_OFFSET that returns in temperatures near real.
   *temp_celsius = ( ( adc_conv_output - 273 - 100 + TS_offset) * 128 ) / TS_gain + 25;
   if (adc_output != 0x0) *adc_output = adc_conv_output;
 }

 if (ADC_Quantiz_bef_TempSensor) { // Restore quantization level defined by preprocessor macro "_Quantization_Level_" at compile time.
    ADC_Quantization_Change(ADC_QuantizLev_8bit);
    // ADMUX |= (1 << ADLAR);
 }

 return rtrn;
}

//--- Set Prescaler ---//
    // Sample rate must be between 50kHz to 200kHz to a resolution of 10 bit. If less bit resolution is acceptable sample rate may be increased.
int8_t SetPrescale (int8_t speed_ = ~0x0){
//  Parameter "speed" arguments:
//      *) "~0x0"  -->> will set the fast possible clock to ADC.
//      *) "0x0"   -->> will set the slower possible clock to ADC.
//      *) "-1"    -->> will decrease ADC clock rate. This value canNOT be used in ADC INITIALIZATION.
//      *) "1"    -->> will increase ADC clock rate. This value canNOT be used in ADC INITIALIZATION.
  float F_adc_max = 200000;  // Maximum frequency for prescaler output clock.   The prescaling is set by the ADPS bits in ADCSRA.
  float F_adc_min = 50000;   // Minimum frequency for prescaler output clock.  // The prescaling is set by the ADPS bits in ADCSRA.


  uint16_t Prescaler_DivMin = F_CPU / F_adc_max;
  uint16_t Prescaler_DivMax = F_CPU / F_adc_min;
  uint8_t Prescaler_set = 1u;
  uint16_t PreDiv = 0x1u;
  if ((speed_ == 0x0) || (speed_ == ~0x0)) {
    for (; Prescaler_set < 8; ++Prescaler_set) {
      PreDiv = (PreDiv << 1);   // Presacler divisors are powers of two.
      if (PreDiv <= Prescaler_DivMin) continue;
      if (speed_ == 0x0) {
        if (PreDiv <= Prescaler_DivMax) break;
        return -1;
      }
      if (PreDiv > Prescaler_DivMax) {
        PreDiv = (PreDiv << 1);
        break;
      }
    }
    if (Prescaler_set == 8) return -2; // CPU clock rate is too fast, prescaler cannot achieve ADC clock rate equal or lower than F_adc_max.
  } else if (speed_ == -1) {  // If the sample-and-hold circuitry has not enough time to charge its capacitor to achieve analog input voltage, ADC clock must be decreased.
    //  Load the value of Prescale divisor.
    PreDiv = (1 << (ADCSRA & 0x7)); // This expression is valid only for microcontrollers which: bit0 of ADCSRA is ADPS0,  bit1 of ADCSRA is ADPS1 and  bit2 of ADCSRA is ADPS2.
//    PreDiv = (PreDiv >> 1);   // Correct the value of the byte formed with bits ADPS2, ADPS1 and ADPS0, to the actual loaded value of Presacler divisors.
    // Increase the value of Prescaler divisor
//    PreDiv = (PreDiv << 1);   // Increase the Presacler divisors.

    if (PreDiv <= Prescaler_DivMin) {
      return -3;  // Prediv is already the lowest value for PrescaleDivisor
    } else if (PreDiv > Prescaler_DivMax) {
      return -4;  // Unexpected error
    }
  } else if (speed_ == 1) {  // If the sample-and-hold circuitry has enough time to charge its capacitor to achieve analog input voltage, ADC clock may be increased to allow higher frequency sample.
    //  Load the value of Prescale divisor.
    PreDiv = (1 << (ADCSRA & 0x7)); // This expression is valid only for microcontrollers which: bit0 of ADCSRA is ADPS0,  bit1 of ADCSRA is ADPS1 and  bit2 of ADCSRA is ADPS2.
    PreDiv = (PreDiv >> 1);   // Correct the value of the byte formed with bits ADPS2, ADPS1 and ADPS0, to the actual loaded value of Presacler divisors.
   // Decreasee the value of Prescaler divisor
    PreDiv = (PreDiv >> 1);   // Decrease the Presacler divisors..

    if (PreDiv > Prescaler_DivMax) {
      return -5;  // Prediv is already the lowest value for PrescaleDivisor
    } else if (PreDiv <= Prescaler_DivMin) {
      return -6;  // Unexpected error
    }
  }

  // Set new value for Prescaler divisor in bits ADPS2,  ADPS1 and ADPS0
  if (Prescaler_set == 7) {     //  PreDiv = 128
    ADCSRA |= (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
  } else if (Prescaler_set == 6) {      //  PreDiv = 64
    ADCSRA &= ~(1 << ADPS0);
    ADCSRA |= (1 << ADPS2) | (1 << ADPS1);
  } else if (Prescaler_set == 5) {     //  PreDiv = 32
    ADCSRA &= ~(1 << ADPS1);
    ADCSRA |= (1 << ADPS2) | (1 << ADPS0);
  } else if (Prescaler_set == 4) {      //  PreDiv = 16
    ADCSRA &= ~((1 << ADPS1) | (1 << ADPS0));
    ADCSRA |= (1 << ADPS2) ;
  } else if (Prescaler_set == 3) {      //  PreDiv = 8
    ADCSRA &= ~(1 << ADPS2);
    ADCSRA |= (1 << ADPS1) | (1 << ADPS0);
  } else if (Prescaler_set == 2) {      //  PreDiv = 4
    ADCSRA &= ~(1 << ADPS1);
    ADCSRA |= (1 << ADPS2) | (1 << ADPS0);
  }
}

int8_t ADC_Mode_Set_AutoTrig(uint8_t source = 0u) {

   if (!ADC_ADMUX_OKtoChange())return -1;  // If No ADC conversion is in progress, function "ADC_ADMUX_OKtoChange()" will return "true".

  // Select the trigger source:
  ADCSRB &= ~(0x7);
  ADCSRB |= (source & 0x7); // This expression is valid only for microcontrollers which: bit0 of ADCSRB is ADTS0,  bit1 of ADCSRB is ADTS1 and  bit2 of ADCSRB is ADTS2.
        // When a positive edge occurs on the selected trigger signal, the ADC prescaler is reset and a conversion is started.
         //    If the trigger signal still is set when the conversion completes, a new conversion will NOT be started.
         // Note that an interrupt flag will be set even if the specific interrupt is disabled or the global interrupt enable
         //    bit in SREG is cleared. A conversion can thus be triggered without causing an interrupt. However, the interrupt
         //    flag must be cleared in order to trigger a new conversion at the next interrupt event.
 // Enable Autotrigger Mode
  ADCSRA |= (1 << ADATE);    // Enable  in AutoTrigger Conversion Mode.

  // Activate ADC Conversion Complete Interrupt Handling vector.
  ADCSRA |= (1 << ADIE);  // Enable ADC Conversion Complete Interrupt handling vector execution.
  sei();   // Enable global interrupt (Status Register bit I).

  return 0;
}

int8_t ADC_Mode_Set_FreeRun(void) {
          // The Free Running Mode requires Interrupt Handling routine to easy save (read) conversion output. The ADC Conversion Complete Interrupt handling routine is presented bellow in this file.
          // In Free Running Mode, ADC will perform successive conversions independently of whether the ADC interrupt flag, ADIF is cleared or not.

  // Set AutoTrigger Mode with Free Running
  return ADC_Mode_Set_AutoTrig(ADC_ModeAutoTrig_Free);

}

int8_t ADC_Mode_Set_SingleConv(uint8_t force) {

  if (force == 1) {
    bool ADC_Enabled = ADCSRA & (1 << ADEN);      // Check the ADC Enable bit to identify if ADC is turned on.
    if (ADC_Enabled)  ADCSRA &= ~(1 << ADEN);     // Turn off ADC .
    ADCSRA &= ~(1 << ADATE);    // Turn off Auto Trigger Mode. This enable Single Conversion Mode.
    if (ADC_Enabled)  ADCSRA |= (1 << ADEN);      // Turn on ADC if it was enabled before this function be called.
  } else {
    if (ADCSRA & (1 << ADSC)) return -1;   // To enter in Single Conversion Mode, the ADC cannot be processing a conversion.
    if (ADCSRA & (1 << ADEN))  return -2;  // The ADC must be disabled to enter in Single Mode Conversion.
    ADCSRA &= ~(1 << ADATE);    // Turn off Auto Trigger Mode. This enable Single Conversion Mode.
  }
  return 0;

}

int8_t ADC_Conversion_DiscardFirst(void) {
// The first conversion after the ADC is switched on (ADEN in ADCSRA is set) takes 25 ADC clock cycles in order to initialize the analog circuitry.
//     When the bandgap reference voltage is used as input to the ADC, it will take a certain time for the voltage to stabilize.
//     If not stabilized, the first value read after the first conversion may be wrong

  uint8_t ADC_InterrputEnableb = ~0x0;

  if ( !( ADCSRA & (1 << ADEN)) ) return -1;  // The ADC must be enabled to Start the first convertion.

  if ( (ADCSRA & (1 << ADATE)) &&    // ADC is in Auto Trigger Mode ADC_ModeAutoTrig_Free
       ( (ADCSRB &0x7) == ADC_ModeAutoTrig_Free) ) {  // Auto Trigger source is in FREE RUNNING.
    return -2;  // To discard the first conversion, the ADC mode must NOT be in FREE RUNNING MODE.
                // It seems not necessary to know the period of the sample rate at Free Running Mode, because it must use interrupt handlig routine to read data.
                // the period of maximun achievable sample rate must be important for other auto trigger sources. In those cases, the first conversion that spend
                // more time ()
  }

  if ( !(ADCSRA & (1 << ADSC)) )  {  // No conversion is in progress.
    ADC_InterrputEnableb =   ADCSRA & (1 << ADIE);  //Check if ADC Conversion Complete Interrupt handling vector execution is enabled.
    ADCSRA &= ~(1 << ADIE);  // Disable ADC Conversion Complete Interruption handling execution.
    ADCSRA |= (1 << ADIF);   // This bit (ADC Interrupt Flag)is set when an ADC conversion completes and the data registers are updated. It is cleared by writing a logical one to it.
    ADCSRA |= (1 << ADSC);   // Start one conversion.
    // while (ADCSRA & (1 << ADSC));   // Wait for conclusion of the required conversion. In Single Conversion Mode, at the end of conversion ADSC is cleared by hardware.
    while ( !(ADCSRA & (1 << ADIF))  );   // Wait for conclusion of the required conversion. At the end of conversion ADIF is set by hardware.
    ADCSRA |= (1 << ADIF);   // This bit (ADC Interrupt Flag) is set when an ADC conversion completes and the data registers are updated. It is cleared by writing a logical one to it.
    if (ADC_InterrputEnableb) {  // If ADIE flag was previously set it must be set before this function return.
      ADCSRA |= (1 << ADIE);  //  set ADIE flag, enabling again  ADC Conversion Complete Interrupt handling vector execution.
    }
  } else {  // When a conversion is in progress, this program will NOT interfer with ADIF falg (in ADCSRA register), ADIE flag or ADC Conversion Complete interrupt handling execution.
    if ( (ADCSRA & (1 << ADIF)) && (ADCSRA & (1 << ADATE) ) ) {
      return -3; // In ADC Auto Trigger Mode (different from Free Running) if ADC Complete Interrupt flag (ADIF) is enabled, according AVR ATmega328P
                 //     datasheet (but I'm not sure) , ADSC flag will not be cleared automatically at the end of conversion.
                 //     The trigger source does the hole of ADSC flag. The only one way to check the conclusion of a conversion is by reading ADIF.
    }
    while ( !(ADCSRA & (1 << ADIF))  );   // Wait for conclusion of the required conversion. At the end of conversion ADIF is set by hardware.
   }

  return 0;

}

void ADC_Enable(void) {
//--- PRR – Power Reduction Register:
PRR &= ~(1 << PRADC);   // The power reduction ADC bit, PRADC, must be disabled by writing a logical zero to enable the ADC.

//-- Enable ADC ---//
ADCSRA |= (1 << ADEN);  // The ADC is turned on by setting the ADC Enable bit, ADEN. This relase the prescaler reset letting it start to count.
                        // Clearing ADEN bit turns off the ADC by keeping prescaler count reseted. Turning the ADC off while a conversion is
                        // in progress, will terminate this conversion.
  // The ADC does not consume power when ADEN is cleared. Switch off the ADC before entering power saving sleep modes.
  // ADCSRA |= (1 << ADEN);  // Disable ADC and turn off its power consumption.
}

void ADC_Disable(void){
//-- Disable ADC ---//
ADCSRA &= ~(1 << ADEN);  // Clearing ADEN bit turns off the ADC by keeping prescaler count reseted. Turning the ADC off while a conversion is
                         // in progress, will terminate this conversion.
                         // The ADC does not consume power when ADEN is cleared. Switch off the ADC before entering power saving sleep modes.

//--- PRR – Power Reduction Register:
PRR |= (1 << PRADC);   // The power reduction ADC bit, PRADC, must be disabled by writing a logical zero to enable the ADC.
                       // Writing a logic one to this bit (PRADC) shuts down the ADC. The ADC must be disabled before shut down.
}

int8_t ADC_Read(_ADC_Out_DT_ * adc_output) {

  if (adc_output == 0x0) return -1;
  if ( ADCSRA & (1 << ADATE)) return -2;  // Auto Trigger Mode is active.
  while (ADCSRA & (1 << ADSC)) {_NOP();_NOP(); _NOP(); _NOP();};  // Wait until conversion is completed.

  if ( ADMUX & (1 << ADLAR) ) {
    * adc_output = ADCH;  // Read ADC conversion output.
  } else {
    * adc_output  = (ADCL);       // To ensure that the content of the data registers belongs to the same conversion, ADCL must be read first.
    * adc_output |= (ADCH << 8);  // A read in ADCL register blocks ADC access to data registers. A read in ADCH register realeases ADC access to data registers.
                             //   Any conversion completed after ADCL is read and before ADCH is read will be lost.
  }

  return 0;
}

//#include <avr/sleep.h>//this AVR library contains the methods that controls the sleep modes.  From directory "C:\Program Files (x86)\Arduino\hardware\tools\avr\avr\include\avr".
#define sleep_cpu()                              \
do {                                             \
  __asm__ __volatile__ ( "sleep" "\n\t" :: );    \
} while(0)

int8_t ADC_Mode_SingleConvNoiseCancel_start(void) {
  // IMPORTANT: before call this function, the function "ADC_Mode_Set_SingleConv(uint8_t force)" must be called to set Single Mode Operation.

          // The Single Conversion Mode with Noise Canceler requires that Interrupt Handling is enabled to wakeup the microcontroller from its sleep mode, in which ADC keep still converting.
          // An ADC Conversion Complete Interrupt handling routine , written to Free Running Mode, is presented bellow in this file.
          // Although, for Single Conversion Mode with Noise Canceler the handlig function could be only:
          //   ISR(ADC_vect) {
          //      do { __asm__ __volatile__ ( "reti" "\n\t" :: ); } while(0);
          //   }

  uint8_t StatusReg_I;
  uint8_t adie;
  // Check initial conditions.
  if (ADCSRA & (1 << ADSC)) return -1;  // To start a Single Conversion with Noise Canceler, ADC cannot be processing a conversion.
  if (!(ADCSRA & (1 << ADEN)))  return -2;  // The ADC must be ensabled to start Single Conversion with Noise Canceler.
      // ADCSRA |= (1 << ADEN));    // Turn on ADC counter.
  if (ADCSRA & (1 << ADATE) ) return -3;  // The Auto Trigger Mode should be disabled to start a Single Conversion with Noise Canceler. Execute the code "ADC_Mode_Set_SingleConv(1)" before calling this one..

  // Save actual state of microcontroller Status Register, SREG, intended to save flag I (Interrupt) status.
  StatusReg_I = SREG;

  // Activate ADC Conversion Complete Interrupt Handling vector.
  adie = ADCSRA & (1 << ADIE);
  ADCSRA |= (1 << ADIE);  // Enable ADC Conversion Complete Interrupt handling vector execution.
  sei();   // Enable global interrupt (Status Register bit I).
  // Select microcontroller sleep mode: ADC Noise Reduction .
      // SMCR – Sleep Mode Control Register
      // Bits 3..1 – SM2..0: Sleep Mode Select Bits 2, 1, and 0 >> (SM2=0, SM1=0, SM0=0 to IDLE) ; (SM2=0, SM1=0, SM0=1 to ADC noise reduction).
  SMCR &= ~((1 << SM2) | (1 << SM1));
  SMCR |= (1 << SM0);
      // Bit 0 – SE: Sleep Enable >> The SE bit must be written to logic one to make the MCU enter the sleep mode when the SLEEP instruction is executed.
  SMCR |= (1 << SE);

  // Enter previous selected leep mode.
  sleep_cpu();
      // The ADC will start a conversion once the CPU has been halted.
      // The ADC interrupt will wake up the CPU and execute the ADC Conversion Complete interrupt routine. Indeed, any ohter interrupt may wake up the CPU.

  // Restore previously value of ADIE.
  if (!adie) ADCSRA &= ~(1 << ADIE);

  // Restore previously value of SREG.
  SREG = StatusReg_I;

  return 0;
}

int8_t ADC_Conversion_Start(void){
  if ( !(ADCSRA & (1 << ADEN)) )  return -1;

//--- Start ADC Conversion ---//
  ADCSRA |= (1 << ADSC);   // The ADSC bit stays high as long as the conversion is in progress and will be cleared by hardware when the conversion is completed.
                           //    If a different data channel is selected while a conversion is in progress, the ADC will finish the current conversion before performing the channel change.
        //  Single Conversion can be started even if AutoTrigger Mode is enabled.
  return 0;
}

int8_t ADC_Init(uint8_t vref, uint8_t quantzlvl, uint8_t inpselected, uint8_t mode){
  // The ARDUINO UNO rev3 Printed Circuit Board has already connected:
  //     *) a 100nF capacitor between  A_REF pin and GND pin;
  //     *) A_VCC pin directly to VCC pin;  - no 10microH between A_VCC and VCC pin, as recomended datasheet -
  //     *) a 100nF capacitor between A_VCC pin (already connected to VCC pin) and GND.

  // To avoid a short circuit between a voltage source possibly connected to A_REF pin and any other internal reference (A_VCC and 1.1V),
  // the default value to initiate V_REF is "ADC_VREF_AREF". But in Arduino PCB A_REF pin is "floating", connected only to a 100nF capacitor which is attached to GND pin.

  uint8_t ret = 0;
  uint8_t returnedFuncID_bits = 3u;  // This function will call a few functions and pass their return value (in case of error/fail) in the "returnedFuncID_bits" Least Significant Bit-LSB. The others MSB will identify the funcation that returned that error value.

  //---  Configure Register ADMUX ---//
  ADMUX = (uint8_t)0x0;
  //  Configure the V_REF
  ret = ADC_VREF_Select(vref); // The options:  {ADC_VREF_AREF , ADC_VREF_AVCC , ADC_VREF_VBg }
  if (ret < 0) return  -( (1 << returnedFuncID_bits) | ( (-ret) & returnedFuncID_bits) );

  //  Configure the significant bits for output (output quantization level) to simplify access to 8 bit output, if required.
  ret = ADC_QuantizationLevel(quantzlvl );  // The options:  {ADC_QuantizLev_8bit , ADC_QuantizLev_10bit }
  if (ret < 0) return  -( (2 << returnedFuncID_bits) | ( (-ret) & returnedFuncID_bits) );

  //  Select analog input to be converted.
  ret = ADC_Input_Select(inpselected); // The options: {ADC_Ainp_A0 , ADC_Ainp_A1 , ADC_Ainp_A2 , ADC_Ainp_A3 , ADC_Ainp_A4 , ADC_Ainp_A5 , ADC_Ainp_TempSensor , ADC_Ainp_VBg , ADC_Ainp_GND }
  if (ret < 0) return  -( (3 << returnedFuncID_bits) | ( (-ret) & returnedFuncID_bits) );


  //---  Configure Register ADCSRA ---//
  ADCSRA = ((uint8_t)0x0u | (1 << ADIF));
  // Define prescaler.
  ret = SetPrescale (~0x0);  // The option: { "~0x0" ( fast possible clock to ADC) , "0x0" (slowest possible clock to ADC) }
  if (ret < 0) return  -( (4 << returnedFuncID_bits) | ( (-ret) & returnedFuncID_bits) );


  //---  Configure Register ADCSRA ---//
  ADCSRB = (uint8_t)0x0u | (ADCSRB &(1 << ACME));   // The ACME bit is related to ANALOG COMPARATOR (between analog inputs pins AIN0 and AIN1. It should not be changed by ADC initialization.
//--- Set AutoTrigger Mode ---//
    // The options for parameter "mode" are : { ADC_ModeAutoTrig_Free , ADC_ModeAutoTrig_AComp , ADC_ModeAutoTrig_ExtIRQ , ADC_ModeAutoTrig_Tmr0MatchA ,
    //                                          ADC_ModeAutoTrig_Tmr0OvFlow , ADC_ModeAutoTrig_Tmr1MatchB , ADC_ModeAutoTrig_Tmr1OvFlow ,
    //                                          ADC_ModeAutoTrig_Tmr1CapEvnt , ~0x0 (for Single Conversion Mode) }
  if (mode == ADC_ModeSingleConv ) {
    ret = ADC_Mode_Set_SingleConv(1u);   //  Default option.
  } else if ( mode == ADC_ModeAutoTrig_Free ) {
    ret = ADC_Mode_Set_FreeRun();
  } else if ( mode > ADC_ModeAutoTrig_Tmr1CapEvnt) {
    return  -( (5 << returnedFuncID_bits)) ;
  } else {
    ret = ADC_Mode_Set_AutoTrig(mode);
  }
  if (ret < 0) return  -( (6 << returnedFuncID_bits) | ( (-ret) & returnedFuncID_bits) );

  ADC_ISR_Initialize();

  ADC_Enable();

  // ADC_Conversion_DiscardFirst();

   return 0;
}

float ADC_SampleRate_ActualMax (void) {
   // Return the maximun sample rate in Hz.
  uint16_t PrescalerVid;   // Set new value for Prescaler divisor in bits ADPS2,  ADPS1 and ADPS0
  if ( !(ADCSRA & (1 << ADPS2)) ){
    if ( !(ADCSRA & (1 << ADPS1)) ){
      if ( !(ADCSRA & (1 << ADPS0)) ){
        PrescalerVid = 2;
      } else {
        PrescalerVid = 2;
      }
    } else {
      if ( !(ADCSRA & (1 << ADPS0)) ){
        PrescalerVid = 4;
      } else {
        PrescalerVid = 8;
      }
    }
  } else {
    if ( !(ADCSRA & (1 << ADPS1)) ){
      if ( !(ADCSRA & (1 << ADPS0)) ){
        PrescalerVid = 16;
      } else {
        PrescalerVid = 32;
      }
    } else {
      if ( !(ADCSRA & (1 << ADPS0)) ){
        PrescalerVid = 64;
      } else {
        PrescalerVid = 128;
      }
    }
  }


  if ((ADCSRA & (1 << ADATE)) && ( (ADCSRB & 0x7) == ADC_ModeAutoTrig_Free ) ){
    return ((float) F_CPU) / (PrescalerVid * 13);
  } else {
    return ((float) F_CPU) / (PrescalerVid * 14);
  }

}

int8_t ADC_VREF_GetSelection (float * vref) {
  uint8_t RefSel_Val = (ADMUX & ((1 << REFS1) | (1 << REFS0))) >> REFS0;   //  This function may work only for AVR microcontrollers that ADMUX register contains both bits REFS1 and REFS0, and the index of REFS1 is one unit gerater than REFS0 index.
  if (RefSel_Val == 0x00) {
    *vref = 0.0f;    // V_REF is actually defined as external voltage source attached to A_REF pin. The value of V_REF is known by hardware designer.
    return -1;
  } else if (RefSel_Val == 0x01){
    *vref = 5.0f;    // V_REF is actually defined as internal connection to A_VCC.
  } else if (RefSel_Val == 0x03){
    *vref = 1.1f;    // V_REF is actually defined as internal connection to Bandgap voltage 1.1V .
  } else {
    *vref = -1.0f;  //  V_REF is actually defined as "Reserved" configuration.
    return -2;      //  V_REF is incorrectly defined to "Reserved" configuration.
  }
  return 0;    // V_REF configuration is defined to an internal voltage reference, known by software.
}


//--- ADC Conversion Complete Interrupt Service Routine and Related Functions---//
void ADC_ISR_Initialize(void) {
  ADC_Out_Buf_circ_BEG = 0x0;
  ADC_Out_Buf_circ_END = 0x0;
  ADC_Out_Buf_circ_TOT = 0x0;
}

uint16_t ADC_outbuf_extract(_ADC_Out_DT_ * buf, uint16_t numb, uint16_t * overlapped) {
//  This function returns the number of ADC conversion output really extracted.
//  Parameter "numb" is the number of ADC conversion output desired for extraction.
//  Parameter "overlapped" points to a uint16_t variable that will receive the number of overwritten ADC output (not extracted previously).
//  Values for "numb" parameter must NOT be high, because this function disable global interrupt while its running.

  int16_t n;
  uint8_t SREG_0 = SREG;   // Save contents of Status Register, SREG.
  cli();   // Disable global interrupt flag in status register.

  if (overlapped != 0x0u) {
    if (ADC_Out_Buf_circ_TOT == ~0x0) {
      *overlapped = ~0x0;  // Its not possible to know how many ADC conversions output were overwritten.
    } else {
      if (ADC_Out_Buf_circ_TOT > _Circular_Buffer_Size_) {
        *overlapped = ADC_Out_Buf_circ_TOT - _Circular_Buffer_Size_;
      } else {
        *overlapped = 0x0u;
      }
    }
  }

  if (numb > _Circular_Buffer_Size_) numb = _Circular_Buffer_Size_ ;
  if (numb > ADC_Out_Buf_circ_TOT) numb = ADC_Out_Buf_circ_TOT ;

  if (ADC_Out_Buf_circ_TOT >= _Circular_Buffer_Size_) {  // Equality stands only for the case when "_Circular_Buffer_Size_ == ~0x0"
    ADC_Out_Buf_circ_BEG = ADC_Out_Buf_circ_END;
    ADC_Out_Buf_circ_TOT = _Circular_Buffer_Size_;   // Stands for the case when "ADC_Out_Buf_circ_TOT > _Circular_Buffer_Size_"
  }

  for ( n = 0; (n < numb) ; ++n, ++buf) {
    *buf =  ADC_Out_Buf_circ[ADC_Out_Buf_circ_BEG];  // Extract ADC conversion output to address pointed by "buf".
    ++ADC_Out_Buf_circ_BEG;    // Update "ADC_Out_Buf_circ_BEG" index.
    if (ADC_Out_Buf_circ_BEG >= _Circular_Buffer_Size_) {   // Value of index "ADC_Out_Buf_circ_BEG" reached memory space out off "ADC_Out_Buf_circ[_Circular_Buffer_Size_]" range.
        ADC_Out_Buf_circ_BEG = 0x0;  // Correct "ADC_Out_Buf_circ_BEG" index value to beginning of circular buffer.
    }
  }

  ADC_Out_Buf_circ_TOT -= n;   // Update ADC_Out_Buf_circ_TOT

  SREG = SREG_0;    // Restore  contents of Status Register, SREG.

  return n;
}

ISR(ADC_vect) {
  _ADC_Out_DT_  ADC_out;

  if ( ADMUX & (1 << ADLAR) ) {
    ADC_out = ADCH;  // Read ADC conversion output.
  } else {

    if (sizeof(_ADC_Out_DT_) == sizeof (uint16_t)) {  //  This expression will evaluate to 'true' only if preprocessor macro "_Quantization_Level_ " was defined as "( ADC_QuantizLev_10bit )"  at compilation time. This results on ADC conversion output resolution of 10 bit,
      ADC_out  = (ADCL);       // To ensure that the content of the data registers belongs to the same conversion, ADCL must be read first.
      ADC_out |= (ADCH << 8);  // A read in ADCL register blocks ADC access to data registers. A read in ADCH register realeases ADC access to data registers.
                    //   Any conversion completed after ADCL is read and before ADCH is read will be lost.
    } else {  //  This program flow will enter here if preprocessor macro "_Quantization_Level_ " was defined as "( ADC_QuantizLev_8bit )" at compilation time, but programmer are reading internal Temperature Sensor (which requires ADC conversion output resolution of 10 bit).
      ADC_out  = (ADCL);       // To ensure that the content of the data registers belongs to the same conversion, ADCL must be read first.
      ADC_Out_Buf_circ[ADC_Out_Buf_circ_END] = ADC_out;  // Save ADC conversion output to circular buffer.
      ++ADC_Out_Buf_circ_END;  // Increment circular buffer index to save actual ADC conversion output.
      if (ADC_Out_Buf_circ_END >= _Circular_Buffer_Size_) ADC_Out_Buf_circ_END = 0x0;  // Adjust the index, if it points out of circular buffer size.
      if (ADC_Out_Buf_circ_TOT != (~0x0u)) ++ADC_Out_Buf_circ_TOT;   // Increment "ADC_Out_Buf_circ_TOT" unless it reaches its maximum value.
      ADC_out  = (ADCH);  // A read in ADCL register blocks ADC access to data registers. A read in ADCH register realeases ADC access to data registers.
                    //   Any conversion completed after ADCL is read and before ADCH is read will be lost.
    }
  }

  ADC_Out_Buf_circ[ADC_Out_Buf_circ_END] = ADC_out;  // Save ADC conversion output to circular buffer.
  ++ADC_Out_Buf_circ_END;  // Increment circular buffer index to save actual ADC conversion output.
  if (ADC_Out_Buf_circ_END >= _Circular_Buffer_Size_) ADC_Out_Buf_circ_END = 0x0;  // Adjust the index, if it points out of circular buffer size.
  if (ADC_Out_Buf_circ_TOT != (~0x0u)) ++ADC_Out_Buf_circ_TOT;   // Increment "ADC_Out_Buf_circ_TOT" unless it reaches its maximum value.

}

//  List of "ISR()" arguments:
//      TIMER0_OVF_vect
//      TIMER1_COMPA_vect
//      TIMER1_COMPB_vect
//      TIMER1_OVF_vect
//      TIMER2_OVF_vect
//      USART_RX_vect
//      USART_UDRE_vect
//      WDT_vect
//      INT0_vect
//      INT1_vect
//      PCINT0_vect
//      PCINT1_vect
//      PCINT2_vect
//      ANALOG_COMP_vect
//      SPI_STC_vect
//      SPM_READY_vect
//      EE_READY_vect




/*
Temperature Sensor:
ADC_output = ( (ADCL) + (ADCH << 8) );
Temp_celsius =  ( ( ADC_output - (273 + 100TS_OFFSET)) * 128 ) / TS_GAIN + 25
TS_GAIN is the unsigned fixed point 8-bit temperature sensor gain factor in 1/128th units stored in the signature row.
TS_OFFSET is the signed twos complement temperature sensor offset reading stored in the signature row.

Signature Byte                  Z-Pointer Address
Device signature byte 1         0x0000
Device signature byte 2         0x0002
Device signature byte 3         0x0004
RC oscillator calibration byte  0x0001
TSOFFSET - temp sensor offset   0x0002
TSGAIN - temp sensor gain       0x0003

The registers and flags required to read Signature Row from software is found in manual
ATmega48A-PA-88A-PA-168A-PA-328-P-DS-DS40002061A.pdf ( downloadable from
 https://ww1.microchip.com/downloads/en/DeviceDoc/ATmega48A-PA-88A-PA-168A-PA-328-P-DS-DS40002061A.pdf ).
The assembly instruction to read Signature Row from software is found in manual
To read the signature row from software, load the Z-pointer with the signature byte address given in Table 26-5 and set the
SIGRD and SPMEN (or SELFPRGEN) bits in SPMCSR. When an LPM instruction is executed within three CPU cycles after the SIGRD and
SPMEN bits are set in SPMCSR, the signature byte value will be loaded in the destination register. The SIGRD and SPMEN
bits will auto-clear upon completion of reading the signature row lock bits or if no LPM instruction is executed within three
CPU cycles. When SIGRD and SPMEN are cleared, LPM will work as described in the Instruction set Manual.


The following code example allows to read signature row data
.equ TS_GAIN = 0x0003
.equ TS_OFFSET = 0x0002
LDI R30,LOW(TS_GAIN)
LDI R31,HIGH (TS_GAIN)
RCALL Read_signature_row
MOV R17,R16; Save R16 result
LDI R30,LOW(TS_OFFSET)
LDI R31,HIGH (TS_OFFSET)
RCALL Read_signature_row
; R16 holds TS_OFFSET and R17 holds TS_GAIN
Read_signature_row:
IN R16,SPMCSR; Wait for SPMEN ready
SBRC R16,SPMEN; Exit loop here when SPMCSR is free
RJMP Read_signature_row
LDI R16,((1<<SIGRD)|(1<<SPMEN)); We need to set SIGRD and SPMEN together
OUT SPMCSR,R16; and execute the LPM within 3 cycles
LPM R16,Z
RET

/**/

//---  From file ...Arduino\hardware\tools\avr\avr\include\avr\boot.h
//  #define boot_signature_byte_get(addr) \
//  (__extension__({                      \
//        uint8_t __result;                         \
//        __asm__ __volatile__                      \
//        (                                         \
//          "sts %1, %2\n\t"                        \
//          "lpm %0, Z" "\n\t"                      \
//          : "=r" (__result)                       \
//          : "i" (_SFR_MEM_ADDR(__SPM_REG)),       \
//            "r" ((uint8_t)(__BOOT_SIGROW_READ)),  \
//            "z" ((uint16_t)(addr))                \
//        );                                        \
//        __result;                                 \
//  }))
