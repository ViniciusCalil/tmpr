#ifndef VIN_ADC_H
  #define VIN_ADC_H

//--------------   PROGRAMMER DEFINITION REQUIRED   -------------//
//  The next two definitions must be supplied by programmers according application

//  1) MACRO _Quantization_Level_
//     Available options:  "(10u)" for 10 bit resolution ; "(8u)" for 8 bit resolution
//         NOTE: supply values inside parentheses with suffix "u", to make it unsigned value.
//               Only values "(10u)" and "(8u)" are available.
//     Quantization Level defines how much significant bits is important to application: 10 bit or 8 bit.
//     The 10 bit resolution require two bytes for storage and, in 8 bit architecture microcontrollers,
//     it also requires more software help for math operations.
  #ifndef _Quantization_Level_
    #define _Quantization_Level_  ( ADC_QuantizLev_10bit )
  #endif // _Quantization_Level_

//  1) MACRO _Circular_Buffer_Size_
//     Available options: should be a "uint16_t" data type value, but not the maximum value "~(0x0u)".
//         NOTE: supply values inside parentheses with suffix "u", to make it unsigned value.
//     This macro sets the size of the circular buffer used to store ADC conversions outputs in ISR.
//     Certain ADC operation modes (Free Running and Single Conversion with Noise Canceler) depends on ISR
//     (Interrupt Service Routine). The ADC conversion output result should be placed in a (circular)
//     buffer. The amount of data required in this buffer depends on: maximum sample rate required
//     by application to realize the ADC conversion; and maximum time interval that "main" routine will
//     extract data from this buffer.
  #ifndef _Circular_Buffer_Size_
    #define _Circular_Buffer_Size_ (14u)
  #endif // _Circular_Buffer_Size_

//------------------------------------------------------------------------//



//
//  #ifdef VIN_ADC_CPP
//    #define _ext_var_
//  #else
//    #define _ext_var_  extern
//  #endif

  #if (_Quantization_Level_ ==  (10u) )
    typedef uint16_t  _ADC_Out_DT_ ;
  #elif (_Quantization_Level_ ==  (8u) )
    typedef uint8_t  _ADC_Out_DT_ ;
  #else
    typedef uint16_t  _ADC_Out_DT_ ;
  #endif
  // For future usage: any change in "_Quantization_Level_" macro option values must be reflected
  // in "const" variables: "ADC_QuantizLev_10bit" and "ADC_QuantizLev_8bit" as well as any other
  // new created "const" variable.

/*

//--- ADC Voltage Reference V_REF constants ---//
//    A default option for V_REF is set to ADC_VREF_AREF to prevent any short circuit between a possible
//    voltage source at A_REF pin and any internal sources references (A_VCC and 1.1V).
_ext_var_ const uint8_t ADC_VREF_AREF = 1u;   // V_REF is attached to external voltage source at A_REF pin (all internal options A_VCC and 1.1V must be turned off):(REFS1=0, REFS0=0)
_ext_var_ const uint8_t ADC_VREF_AVCC = 2u;   // V_REF is attached to internal A_VCC (but hardware must has an external capacitor between A_REF pin and GND): (REFS1=0, REFS0=1);
_ext_var_ const uint8_t ADC_VREF_VBg =  3u;   // V_REF is attached to internal 1.1V V_Bandgap (but hardware must has an external capacitor between A_REF pin and GND): (REFS1=1, REFS0=1);

//--- Quantization Level (10-bit or 8-bit) constants ----//
_ext_var_ const uint8_t ADC_QuantizLev_8bit =  8u;  // Output of ADC can be accessed with  just a single read at ADCH register, but only 8 MSB are present there.
_ext_var_ const uint8_t ADC_QuantizLev_10bit = 10u;  // Output of ADC can be accessed with two registers read: ADCH (with 2 MSB)  and ADCL (with 8 LSB).

//--- Analog Input channel constants ---//
_ext_var_ const uint8_t ADC_Ainp_A0 =  0u;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
_ext_var_ const uint8_t ADC_Ainp_A1 =  1u;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
_ext_var_ const uint8_t ADC_Ainp_A2 =  2u;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
_ext_var_ const uint8_t ADC_Ainp_A3 =  3u;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
_ext_var_ const uint8_t ADC_Ainp_A4 =  4u;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
_ext_var_ const uint8_t ADC_Ainp_A5 =  5u;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
_ext_var_ const uint8_t ADC_Ainp_TempSensor = 8u;  // AVR ATmega328P internal Temperature Sensor is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
_ext_var_ const uint8_t ADC_Ainp_VBg = 14u;  // AVR ATmega328P internal Bandgap 1.1V is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
_ext_var_ const uint8_t ADC_Ainp_GND = 15u;  // AVR ATmega328P internal GND is selected by Input Multiplexer as its output to the analog comparator input of the ADC.

//--- ADC modes: Single Conversion and AutoTrigger sources constants ---//
_ext_var_ const uint8_t ADC_ModeAutoTrig_Free        = 0u;    // For Free Running Mode (start a new conversion as soon as the currently one finishes.)
_ext_var_ const uint8_t ADC_ModeAutoTrig_AComp       = 1u;    // For ARDUINO Analog Comparator Circuit.
_ext_var_ const uint8_t ADC_ModeAutoTrig_ExtIRQ      = 2u;    // For ARDUINO PCB pin 3 (AVR ATmega328P: pin 5, PD3, INT1).
_ext_var_ const uint8_t ADC_ModeAutoTrig_Tmr0MatchA  = 3u;    // For ARDUINO Timer/Counter0 Compare Match A (interrupt flag bit).
_ext_var_ const uint8_t ADC_ModeAutoTrig_Tmr0OvFlow  = 4u;    // For ARDUINO Timer/Counter0 Overflow (interrupt flag bit).
_ext_var_ const uint8_t ADC_ModeAutoTrig_Tmr1MatchB  = 5u;    // For ARDUINO Timer/Counter1 Compare Match A (interrupt flag bit).
_ext_var_ const uint8_t ADC_ModeAutoTrig_Tmr1OvFlow  = 6u;    // For ARDUINO Timer/Counter1 Overflow (interrupt flag bit).
_ext_var_ const uint8_t ADC_ModeAutoTrig_Tmr1CapEvnt = 7u;    // For ARDUINO Timer/Counter1 Capture Event (interrupt flag bit).
_ext_var_ const uint8_t ADC_ModeSingleConv           = 16u;
*/


// * - * - * - * - * - * -    GLOBAL VARIABLES DECLARATION  - * - * - * - * - * - * - * - * //

//--- ADC Voltage Reference V_REF constants ---//
//    A default option for V_REF is set to ADC_VREF_AREF to prevent any short circuit between a possible
//    voltage source at A_REF pin and any internal sources references (A_VCC and 1.1V).
extern const uint8_t ADC_VREF_AREF;   // V_REF is attached to external voltage source at A_REF pin (all internal options A_VCC and 1.1V must be turned off):(REFS1=0, REFS0=0)
extern const uint8_t ADC_VREF_AVCC;   // V_REF is attached to internal A_VCC (but hardware must has an external capacitor between A_REF pin and GND): (REFS1=0, REFS0=1);
extern const uint8_t ADC_VREF_VBg;   // V_REF is attached to internal 1.1V V_Bandgap (but hardware must has an external capacitor between A_REF pin and GND): (REFS1=1, REFS0=1);

//--- Quantization Level (10-bit or 8-bit) constants ----//
extern const uint8_t ADC_QuantizLev_8bit;   // Output of ADC can be accessed with  just a single read at ADCH register, but only 8 MSB are present there.
extern const uint8_t ADC_QuantizLev_10bit;  // Output of ADC can be accessed with two registers read: ADCH (with 2 MSB)  and ADCL (with 8 LSB).

//--- Analog Input channel constants ---//
extern const uint8_t ADC_Ainp_A0;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
extern const uint8_t ADC_Ainp_A1;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
extern const uint8_t ADC_Ainp_A2;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
extern const uint8_t ADC_Ainp_A3;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
extern const uint8_t ADC_Ainp_A4;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
extern const uint8_t ADC_Ainp_A5;  // Arduino PCB pin A0 is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
extern const uint8_t ADC_Ainp_TempSensor;  // AVR ATmega328P internal Temperature Sensor is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
extern const uint8_t ADC_Ainp_VBg; // AVR ATmega328P internal Bandgap 1.1V is selected by Input Multiplexer as its output to the analog comparator input of the ADC.
extern const uint8_t ADC_Ainp_GND; // AVR ATmega328P internal GND is selected by Input Multiplexer as its output to the analog comparator input of the ADC.

//--- ADC modes: Single Conversion and AutoTrigger sources constants ---//
extern const uint8_t ADC_ModeAutoTrig_Free       ;    // For Free Running Mode (start a new conversion as soon as the currently one finishes.)
extern const uint8_t ADC_ModeAutoTrig_AComp      ;    // For ARDUINO Analog Comparator Circuit.
extern const uint8_t ADC_ModeAutoTrig_ExtIRQ     ;    // For ARDUINO PCB pin 3 (AVR ATmega328P: pin 5, PD3, INT1).
extern const uint8_t ADC_ModeAutoTrig_Tmr0MatchA ;    // For ARDUINO Timer/Counter0 Compare Match A (interrupt flag bit).
extern const uint8_t ADC_ModeAutoTrig_Tmr0OvFlow ;    // For ARDUINO Timer/Counter0 Overflow (interrupt flag bit).
extern const uint8_t ADC_ModeAutoTrig_Tmr1MatchB ;    // For ARDUINO Timer/Counter1 Compare Match A (interrupt flag bit).
extern const uint8_t ADC_ModeAutoTrig_Tmr1OvFlow ;    // For ARDUINO Timer/Counter1 Overflow (interrupt flag bit).
extern const uint8_t ADC_ModeAutoTrig_Tmr1CapEvnt;    // For ARDUINO Timer/Counter1 Capture Event (interrupt flag bit).
extern const uint8_t ADC_ModeSingleConv          ;

// If Noise Canceler is used (in Single Conversion Mode), an ADC Conversion Complete Interrupt handling routine must be defined.
// If Free Running Mode is used, to easy for reading the conversion output, an ADC Conversion Complete Interrupt handling routine can be defined.
// #include <avr/interrupt.h>

//--- Circular Buffer: Single Conversion and AutoTrigger sources constants ---//

extern volatile _ADC_Out_DT_  ADC_Out_Buf_circ[_Circular_Buffer_Size_]; // Buffer used by ADC Conversion Complete Interrupt handling routine.
extern volatile uint16_t ADC_Out_Buf_circ_BEG;   // This is the index of "ADC_Out_Buf_circ[]" array, from where the next ADC conversion output will be
                                                 //     extracted by the "main()" routine (with or with out overlap).
                                                 //     An overlap occur when the ADC conversion output saved into circular buffer "ADC_Out_Buf_circ"
                                                 //     (by ADC Conversion Complete Interrupt handling routine) starts to rewritten the oldest ones.

extern volatile uint16_t ADC_Out_Buf_circ_END;   // This is the index of "ADC_Out_Buf_circ[]" array, to where the next ADC conversion output will be
                                                 //     saved by ADC Conversion Complete Interrupt handling function (with or with out overlap).

extern volatile uint16_t ADC_Out_Buf_circ_TOT;   // Number of ADC conversion output that has NOT been extracted from "main()" routine (with or with
                                                 //     out overlap). If "ADC_Out_Buf_circ_TOT" value is greater than "_Circular_Buffer_Size_", then
                                                 //     an overlap occurred.

// * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * //


//---  Function Prototypes  ---//
bool     ADC_ADMUX_OKtoChange(void);
int8_t   ADC_VREF_Select(uint8_t ref = ADC_VREF_AREF);
int8_t   ADC_VREF_Change(uint8_t ref );
int8_t   ADC_QuantizationLevel(uint8_t lev = ADC_QuantizLev_10bit);
int8_t   ADC_Quantization_Change(uint8_t lev);
int8_t   ADC_Input_Select(uint8_t inp = ADC_Ainp_VBg);
int8_t   ADC_Input_Change(uint8_t inp);
int8_t   SetPrescale (int8_t speed_ = ~0x0);
int8_t   ADC_Mode_Set_AutoTrig(uint8_t source = 0u);
int8_t   ADC_Mode_Set_FreeRun(void);
int8_t   ADC_Mode_Set_SingleConv(uint8_t force = 1);
int8_t   ADC_Conversion_DiscardFirst(void);
void     ADC_Enable(void);
void     ADC_Disable(void);
int8_t   ADC_Read(_ADC_Out_DT_ * adc_output);
int8_t   ADC_Mode_SingleConvNoiseCancel_start(void);
int8_t   ADC_Conversion_Start(void);
int8_t   ADC_Init(uint8_t vref = ADC_VREF_AREF, uint8_t quantzlvl = ADC_QuantizLev_10bit ,
                uint8_t inpselected = ADC_Ainp_VBg  , uint8_t mode = ADC_ModeSingleConv );
float    ADC_SampleRate_ActualMax (void);
int8_t   ADC_VREF_GetSelection (float *vref);
void     ADC_ISR_Initialize(void);
uint16_t ADC_outbuf_extract(_ADC_Out_DT_ * buf, uint16_t numb = 0x1u, uint16_t *overlapped = 0x0u);

int8_t ADC_Input_SetTemperatureSensor (void);
int8_t ADC_Read_TeperatureSensor(int16_t *temp_celsius, uint8_t noisecanceler = 0u, uint16_t * adc_output = 0x0u );
#ifndef _NOP()
  #define _NOP() do { __asm__ volatile ("nop"); } while (0)
#endif   //  _NOP()
  


#endif // VIN_ADC_H
